$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$framework = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe'
if (-not (Test-Path $framework)) { throw 'Compilateur .NET Framework v4 introuvable. Contactez IT.' }
$refs = @('WindowsBase.dll','PresentationCore.dll','PresentationFramework.dll','System.Xaml.dll','System.Web.Extensions.dll','System.dll','System.Core.dll')
$args = @('/nologo','/target:winexe','/out:CalculatricePremium.exe') + ($refs | ForEach-Object { '/reference:' + $_ }) + @('Program.cs')
& $framework @args
if ($LASTEXITCODE -ne 0) { throw 'Compilation C# en echec. Voir les messages ci-dessus.' }
Write-Host 'Compilation terminee : CalculatricePremium.exe' -ForegroundColor Green

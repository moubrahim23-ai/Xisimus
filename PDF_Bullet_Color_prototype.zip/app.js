pdfjsLib.GlobalWorkerOptions.workerSrc='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
const $=id=>document.getElementById(id);
const BULLET_SET=new Set(['•','●','○','■','▪','◦','‣','⁃','◆','□','∙','◉','○','Ø']);
let sourceBytes=null, pdfDoc=null, found=[], pageDims=[], colorMap=new Map();
$('file').addEventListener('change',e=>{if(e.target.files[0])openFile(e.target.files[0])});
$('drop').addEventListener('dragover',e=>{e.preventDefault();$('drop').style.borderColor='#285dcc'});
$('drop').addEventListener('dragleave',()=>$('drop').style.borderColor='');
$('drop').addEventListener('drop',e=>{e.preventDefault();$('drop').style.borderColor='';const f=e.dataTransfer.files[0];if(f&&f.type==='application/pdf')openFile(f);else alert('Veuillez déposer un PDF.')});
$('rescan').onclick=()=>sourceBytes&&analyze();
async function openFile(file){$('fileName').textContent=file.name+' · '+(file.size/1048576).toFixed(2)+' Mo';$('app').classList.remove('hidden');$('status').textContent='Analyse du document…';sourceBytes=new Uint8Array(await file.arrayBuffer());await analyze()}
async function analyze(){
 try{
 pdfDoc=await pdfjsLib.getDocument({data:sourceBytes.slice()}).promise;
 found=[];pageDims=[];colorMap.clear();$('previews').innerHTML='';
 $('pages').textContent=pdfDoc.numPages;
 for(let p=1;p<=pdfDoc.numPages;p++){
  const page=await pdfDoc.getPage(p),vp=page.getViewport({scale:1}),text=await page.getTextContent();
  pageDims.push({width:vp.width,height:vp.height});
  for(const it of text.items){if(!it.str)continue;for(const ch of it.str){if(BULLET_SET.has(ch)){found.push({page:p,char:ch,x:it.transform[4],baseline:it.transform[5],fontSize:Math.abs(it.transform[3])||8,width:Math.max(it.width||5,4),font:it.fontName||''})}}}
  const scale=Math.min(1.1,850/vp.width),small=page.getViewport({scale}),canvas=document.createElement('canvas');canvas.width=small.width;canvas.height=small.height;
  await page.render({canvasContext:canvas.getContext('2d'),viewport:small}).promise;
  const ctx=canvas.getContext('2d'),pix=ctx.getImageData(0,0,canvas.width,canvas.height).data,counts=new Map();
  for(let i=0;i<pix.length;i+=20){let r=pix[i],g=pix[i+1],b=pix[i+2],a=pix[i+3];if(a<200||(r>247&&g>247&&b>247))continue;let rgb=[r,g,b].map(v=>Math.round(v/8)*8),key=rgb.join(',');counts.set(key,(counts.get(key)||0)+1)}
  for(const [k,v] of counts)colorMap.set(k,(colorMap.get(k)||0)+v);
  if(p<=8){const box=document.createElement('div');box.className='preview';box.append(canvas);const sm=document.createElement('small');sm.textContent='Page '+p;box.append(sm);$('previews').append(box)}
 }
 $('count').textContent=found.length;
 renderPalette();
 renderBullets();
 $('status').textContent=found.length?`${found.length} caractère(s) de puce repéré(s).`:'Aucune puce reconnue dans la couche texte.';
 $('export').disabled=!found.length;
 }catch(e){console.error(e);$('status').textContent='Lecture impossible : PDF protégé, endommagé ou non pris en charge.'}
}
function renderPalette(){
 const entries=[...colorMap.entries()].sort((a,b)=>b[1]-a[1]).slice(0,25);$('ncolors').textContent=entries.length;
 const host=$('palette'),sel=$('oldColor');host.innerHTML='';sel.innerHTML='';
 entries.forEach(([rgb,n],i)=>{const [r,g,b]=rgb.split(',').map(Number),hex='#'+[r,g,b].map(v=>v.toString(16).padStart(2,'0')).join('').toUpperCase();const row=document.createElement('div');row.className='swatchrow';const sw=document.createElement('span');sw.className='swatch';sw.style.background=hex;const meta=document.createElement('div');const strong=document.createElement('b');strong.textContent=hex;const small=document.createElement('small');small.textContent=`RGB ${r}, ${g}, ${b} · ${n.toLocaleString('fr-FR')} pixels`;meta.append(strong,small);const radio=document.createElement('input');radio.type='radio';radio.name='palette';radio.value=hex;radio.checked=i===0;radio.onchange=()=>sel.value=hex;row.append(sw,meta,radio);host.append(row);const opt=document.createElement('option');opt.value=hex;opt.textContent=hex;sel.append(opt)});
 // Pour le PDF de test, présélectionne la couleur réellement relevée dans les glyphes.
 if(entries.some(([k])=>k==='216,184,128'))sel.value='#D8B880';
}
function renderBullets(){
 const host=$('bullets');host.innerHTML='';
 const counts=new Map();found.forEach((b,i)=>{const key=b.char;counts.set(key,(counts.get(key)||0)+1)});
 for(const [ch,n] of counts){const lab=document.createElement('label');lab.className='chip';const cb=document.createElement('input');cb.type='checkbox';cb.checked=true;cb.dataset.char=ch;const glyph=document.createElement('strong');glyph.textContent=ch;lab.append(cb,glyph,document.createTextNode(`${n} occurrence(s)`));host.append(lab)}
}
$('export').onclick=async()=>{
 try{
 $('export').disabled=true;$('status').textContent='Création du PDF…';
 const selected=new Set([...$('bullets').querySelectorAll('input:checked')].map(x=>x.dataset.char));
 const old=$('oldColor').value,newHex=$('newColor').value,mask=$('maskColor').value;
 if(!selected.size)throw Error('Sélectionnez au moins un caractère de puce.');
 const {PDFDocument,StandardFonts,rgb}=PDFLib;
 const out=await PDFDocument.load(sourceBytes,{ignoreEncryption:false});
 const font=await out.embedFont(StandardFonts.Helvetica);
 const parse=h=>[1,3,5].map(i=>parseInt(h.slice(i,i+2),16)/255);
 const [mr,mg,mb]=parse(mask),[nr,ng,nb]=parse(newHex);
 let changed=0;
 found.forEach(b=>{
  if(!selected.has(b.char))return;
  const page=out.getPage(b.page-1),dim=pageDims[b.page-1];
  // Rectangle local autour du glyphe. Il faut que maskColor corresponde exactement au fond.
  const h=Math.max(6,b.fontSize*1.12),w=Math.max(4.5,b.width+1.2);
  const x=b.x-0.6,y=dim.height-b.baseline-b.fontSize*0.27;
  page.drawRectangle({x,y,width:w,height:h,color:rgb(mr,mg,mb),borderWidth:0});
  // Une puce circulaire dessinée en vectoriel évite les problèmes d'encodage de police.
  page.drawCircle({x:x+w/2,y:y+h/2,radius:Math.min(h*0.19,w*0.22),color:rgb(nr,ng,nb),borderWidth:0});
  changed++;
 });
 const bytes=await out.save({useObjectStreams:false});
 const blob=new Blob([bytes],{type:'application/pdf'}),url=URL.createObjectURL(blob),a=document.createElement('a');
 a.href=url;a.download='PDF_puces_recolorees.pdf';a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);
 $('status').textContent=`Export lancé : ${changed} puce(s) recolorée(s). Vérifiez le PDF et ses balises.`;
 }catch(e){alert(e.message||String(e));$('status').textContent='Export impossible.'}
 finally{$('export').disabled=false}
};
Attribute VB_Name = "ImporterFeuil1"
Option Explicit
' ------------------------------------------------------------------
' Importe la Feuil1 du fichier canevas dans la feuille Src_Feuil1.
' Tout le reste (affectation aux activites, CA, Recap) se recalcule.
' Installation : Alt+F11 > Fichier > Importer un fichier... > ce .bas,
'                puis enregistrer le classeur en .xlsm.
' Lancement    : Alt+F8 > ImporterFeuil1
' Source       : Parametres!B10 = dossier OU fichier (vide = fenetre de choix)
'                Parametres!B11 = motif du nom (le plus recent est retenu)
'                Parametres!B12 = journal du dernier import
' La feuille source est reconnue par A1 = "CLIENT FINAL".
' ------------------------------------------------------------------

Public Sub ImporterFeuil1()
    Dim wsP As Worksheet, fichier As String, wbSrc As Workbook
    Dim wsS As Worksheet, wsD As Worksheet, ur As Range, v As Variant, msg As String
    Set wsP = ThisWorkbook.Worksheets("Parametres")
    fichier = ResoudreFichier(Trim$(CStr(wsP.Range("B10").Value)), Trim$(CStr(wsP.Range("B11").Value)))
    If fichier = "" Then Exit Sub

    On Error GoTo Fin
    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.Calculation = xlCalculationManual

    Set wbSrc = Workbooks.Open(fichier, ReadOnly:=True, UpdateLinks:=0)
    Dim ws As Worksheet
    For Each ws In wbSrc.Worksheets
        If UCase$(Trim$(CStr(ws.Cells(1, 1).Value))) = "CLIENT FINAL" Then Set wsS = ws: Exit For
    Next ws
    If wsS Is Nothing Then
        wbSrc.Close SaveChanges:=False
        Err.Raise vbObjectError + 1, , "Aucune feuille avec 'CLIENT FINAL' en A1 dans " & fichier
    End If

    Set wsD = ThisWorkbook.Worksheets("Src_Feuil1")
    wsD.Cells.ClearContents
    Set ur = wsS.UsedRange
    v = ur.Value2
    If IsArray(v) Then
        wsD.Cells(ur.Row, ur.Column).Resize(ur.Rows.Count, ur.Columns.Count).Value2 = v
    Else
        wsD.Cells(ur.Row, ur.Column).Value2 = v
    End If
    wsP.Range("B12").Value = Format(Now, "dd/mm/yyyy hh:nn") & " - " & Dir(fichier) & " - " & ur.Rows.Count & " lignes"
    wbSrc.Close SaveChanges:=False
Fin:
    msg = Err.Description
    Application.Calculation = xlCalculationAutomatic
    Application.CalculateFull
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    If msg <> "" Then
        MsgBox "Import interrompu : " & msg, vbCritical
    Else
        MsgBox "Feuil1 importee. Verifiez la feuille Controles (lignes non affectees).", vbInformation
    End If
End Sub

Private Function ResoudreFichier(chemin As String, motif As String) As String
    Dim f As String, best As String, bestDate As Date, d As Date
    If motif = "" Then motif = "*.xls*"
    If chemin = "" Then
        With Application.FileDialog(msoFileDialogFilePicker)
            .Title = "Choisir le fichier canevas"
            If .Show = -1 Then ResoudreFichier = .SelectedItems(1)
        End With
        Exit Function
    End If
    If Dir(chemin, vbDirectory) = "" Then
        MsgBox "Chemin introuvable : " & chemin, vbExclamation: Exit Function
    End If
    If (GetAttr(chemin) And vbDirectory) = 0 Then ResoudreFichier = chemin: Exit Function
    If Right$(chemin, 1) <> Application.PathSeparator Then chemin = chemin & Application.PathSeparator
    f = Dir(chemin & motif)
    Do While f <> ""
        If Left$(f, 2) <> "~$" Then
            d = FileDateTime(chemin & f)
            If best = "" Or d > bestDate Then best = f: bestDate = d
        End If
        f = Dir()
    Loop
    If best = "" Then MsgBox "Aucun fichier '" & motif & "' dans " & chemin, vbExclamation: Exit Function
    ResoudreFichier = chemin & best
End Function

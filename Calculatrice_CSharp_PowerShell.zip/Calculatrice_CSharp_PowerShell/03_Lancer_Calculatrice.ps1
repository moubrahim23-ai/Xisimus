$exe = Join-Path $PSScriptRoot 'Calculatrice.exe'
if (-not (Test-Path $exe)) { Write-Host 'Compilez d abord avec 01_Compiler_CSharp.ps1'; exit 1 }
Start-Process -FilePath $exe -ArgumentList 'http://localhost:8090'

CALCULATRICE C# + POWERSHELL - TEST LOCAL WINDOWS

PRE-REQUIS : Windows PowerShell 5.1, compilateur C# .NET Framework accessible via Add-Type.
Aucune installation NuGet, Node ou Python.

1. Extraire le ZIP dans un dossier autorise, accessible en ecriture.
2. Ouvrir Windows PowerShell dans ce dossier.
3. Compiler : .\01_Compiler_CSharp.ps1
4. Dans une autre fenetre PowerShell, lancer : .\02_Demarrer_Serveur.ps1
5. Lancer : .\03_Lancer_Calculatrice.ps1
6. Calculer 12 + 8. Le resultat et l'historique apparaissent dans la fenetre.
7. Verifier data\historique.json, puis fermer et rouvrir l'application : l'historique doit persister.
8. Arreter le serveur avec Ctrl+C dans sa fenetre.

API :
GET  http://localhost:8090/api/health
GET  http://localhost:8090/api/history
POST http://localhost:8090/api/calculate  JSON {"a":12,"b":8,"op":"+"}

SECURITE : ecoute sur localhost uniquement ; pas d'acces distant ; pas d'authentification.
Usage de demonstration uniquement, sur poste et port autorises par votre service IT.
Ne pas utiliser pour contourner une politique de securite ou une alerte Symantec.
Les calculs sont effectues par PowerShell ; l'interface C# ne fait que les envoyer et afficher l'historique.

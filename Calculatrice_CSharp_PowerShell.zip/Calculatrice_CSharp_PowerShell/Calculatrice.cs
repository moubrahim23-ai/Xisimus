using System;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Net;
using System.Text;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using System.Collections.Generic;

public class Calculatrice : Form {
    TextBox first = new TextBox(), second = new TextBox();
    ComboBox operation = new ComboBox();
    Label result = new Label(), status = new Label();
    ListBox history = new ListBox();
    string endpoint;
    JavaScriptSerializer serializer = new JavaScriptSerializer();

    public Calculatrice(string url) {
        endpoint = url.TrimEnd('/');
        Text = "Calculatrice C# + serveur PowerShell";
        Size = new Size(650, 550); MinimumSize = new Size(580, 450);
        StartPosition = FormStartPosition.CenterScreen;
        Font = new Font("Segoe UI", 10);
        var layout = new TableLayoutPanel { Dock=DockStyle.Fill, Padding=new Padding(16), ColumnCount=2, RowCount=7 };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 45));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 55));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 43));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 43));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 43));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 49));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 35));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        Controls.Add(layout);
        layout.Controls.Add(new Label {Text="Premier nombre", AutoSize=true},0,0);
        layout.Controls.Add(first,1,0); first.Dock=DockStyle.Fill;
        layout.Controls.Add(new Label {Text="Operation", AutoSize=true},0,1);
        operation.Items.AddRange(new object[]{"+","-","*","/"}); operation.SelectedIndex=0; operation.DropDownStyle=ComboBoxStyle.DropDownList; operation.Dock=DockStyle.Fill;
        layout.Controls.Add(operation,1,1);
        layout.Controls.Add(new Label {Text="Deuxieme nombre", AutoSize=true},0,2);
        layout.Controls.Add(second,1,2); second.Dock=DockStyle.Fill;
        var calculate = new Button {Text="Calculer et enregistrer", Dock=DockStyle.Fill}; calculate.Click += (s,e)=>Calculate();
        layout.Controls.Add(calculate,0,3); layout.SetColumnSpan(calculate,2);
        result.Text="Resultat : -"; result.Font=new Font("Segoe UI",14,FontStyle.Bold); result.Dock=DockStyle.Fill;
        layout.Controls.Add(result,0,4); layout.SetColumnSpan(result,2);
        var bar = new FlowLayoutPanel {Dock=DockStyle.Fill};
        var refresh = new Button {Text="Actualiser historique", AutoSize=true}; refresh.Click+=(s,e)=>RefreshHistory(); bar.Controls.Add(refresh);
        status.Text="Connexion..."; status.AutoSize=true; bar.Controls.Add(status);
        layout.Controls.Add(bar,0,5); layout.SetColumnSpan(bar,2);
        history.Dock=DockStyle.Fill; history.HorizontalScrollbar=true;
        layout.Controls.Add(history,0,6); layout.SetColumnSpan(history,2);
        Shown+=(s,e)=>RefreshHistory();
    }
    string Request(string path, string method, string json=null) {
        var req=(HttpWebRequest)WebRequest.Create(endpoint+path);
        req.Method=method; req.Timeout=4000; req.ContentType="application/json; charset=utf-8";
        if(json!=null) { var bytes=Encoding.UTF8.GetBytes(json); req.ContentLength=bytes.Length; using(var stream=req.GetRequestStream()) stream.Write(bytes,0,bytes.Length); }
        try { using(var resp=(HttpWebResponse)req.GetResponse()) using(var reader=new StreamReader(resp.GetResponseStream(),Encoding.UTF8)) return reader.ReadToEnd(); }
        catch(WebException ex) {
            if(ex.Response!=null) using(var reader=new StreamReader(ex.Response.GetResponseStream())) {
                var raw=reader.ReadToEnd(); try {var err=serializer.Deserialize<Dictionary<string,object>>(raw); throw new Exception(Convert.ToString(err["error"]));} catch(KeyNotFoundException) {throw new Exception(raw);} }
            throw new Exception("Serveur inaccessible : "+ex.Message);
        }
    }
    bool ParseNumber(string input, out double number) {
        return double.TryParse(input,NumberStyles.Float,CultureInfo.CurrentCulture,out number) ||
               double.TryParse(input.Replace(',','.'),NumberStyles.Float,CultureInfo.InvariantCulture,out number);
    }
    void Calculate() {
        double a,b;
        if(!ParseNumber(first.Text,out a) || !ParseNumber(second.Text,out b) || Double.IsNaN(a) || Double.IsInfinity(a) || Double.IsNaN(b) || Double.IsInfinity(b)) {
            MessageBox.Show("Saisissez deux nombres valides."); return;
        }
        try {
            var payload=serializer.Serialize(new Dictionary<string,object>{{"a",a},{"b",b},{"op",operation.Text}});
            var data=serializer.Deserialize<Dictionary<string,object>>(Request("/api/calculate","POST",payload));
            var item=(Dictionary<string,object>)data["item"];
            result.Text="Resultat : "+Convert.ToString(item["result"],CultureInfo.CurrentCulture);
            RefreshHistory();
        } catch(Exception ex) {MessageBox.Show(ex.Message,"Erreur",MessageBoxButtons.OK,MessageBoxIcon.Warning);}
    }
    void RefreshHistory() {
        try {
            var data=serializer.Deserialize<Dictionary<string,object>>(Request("/api/history","GET"));
            var items=(System.Collections.ArrayList)data["items"];
            history.Items.Clear();
            for(int i=items.Count-1;i>=0;i--) {
                var item=(Dictionary<string,object>)items[i];
                history.Items.Add(string.Format("{0}  |  {1} {2} {3} = {4}",item["date"],item["a"],item["op"],item["b"],item["result"]));
            }
            status.Text="Serveur connecte - "+items.Count+" calcul(s)";
        } catch(Exception ex) {status.Text="Serveur non disponible"; MessageBox.Show(ex.Message,"Connexion",MessageBoxButtons.OK,MessageBoxIcon.Warning);}
    }
    [STAThread] public static void Main(string[] args) {
        Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new Calculatrice(args.Length>0 ? args[0] : "http://localhost:8090"));
    }
}

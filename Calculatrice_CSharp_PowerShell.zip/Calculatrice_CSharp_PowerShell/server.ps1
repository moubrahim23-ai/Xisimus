param([int]$Port = 8090)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$dataDir = Join-Path $root 'data'
New-Item -ItemType Directory -Path $dataDir -Force | Out-Null
$historyFile = Join-Path $dataDir 'historique.json'
if (-not (Test-Path $historyFile)) { '[]' | Set-Content -LiteralPath $historyFile -Encoding UTF8 }
$listener = New-Object System.Net.HttpListener
$prefix = "http://localhost:$Port/"
$listener.Prefixes.Add($prefix)
try { $listener.Start() } catch { Write-Host "Impossible de demarrer sur $prefix : $_" -ForegroundColor Red; exit 1 }
Write-Host "Serveur local actif : $prefix" -ForegroundColor Green
Write-Host "Historique : $historyFile"
Write-Host 'Ctrl+C pour arreter.'
function Send-Json($ctx, [int]$status, $obj) {
    $json = ConvertTo-Json -InputObject $obj -Depth 8 -Compress
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $ctx.Response.StatusCode = $status
    $ctx.Response.ContentType = 'application/json; charset=utf-8'
    $ctx.Response.ContentLength64 = $bytes.Length
    try { $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length) } finally { $ctx.Response.Close() }
}
function Read-History {
    $raw = [IO.File]::ReadAllText($historyFile, [Text.Encoding]::UTF8)
    if ([string]::IsNullOrWhiteSpace($raw)) { return ,@() }
    $parsed = ConvertFrom-Json -InputObject $raw
    return ,@($parsed)
}
try {
    while ($listener.IsListening) {
        $ctx = $listener.GetContext()
        try {
            $method = $ctx.Request.HttpMethod
            $path = $ctx.Request.Url.AbsolutePath
            if ($method -eq 'GET' -and $path -eq '/api/health') {
                Send-Json $ctx 200 @{ok=$true; service='Calculatrice PS'; port=$Port}
            } elseif ($method -eq 'GET' -and $path -eq '/api/history') {
                $items = Read-History
                Send-Json $ctx 200 @{items=@($items)}
            } elseif ($method -eq 'POST' -and $path -eq '/api/calculate') {
                $reader = New-Object IO.StreamReader($ctx.Request.InputStream, [Text.Encoding]::UTF8)
                try { $body = $reader.ReadToEnd() } finally { $reader.Dispose() }
                $inputObj = ConvertFrom-Json -InputObject $body
                $a = [double]$inputObj.a
                $b = [double]$inputObj.b
                $op = [string]$inputObj.op
                if ([double]::IsNaN($a) -or [double]::IsInfinity($a) -or [double]::IsNaN($b) -or [double]::IsInfinity($b)) { throw 'Valeur numerique invalide.' }
                switch ($op) {
                    '+' {$result = $a + $b}
                    '-' {$result = $a - $b}
                    '*' {$result = $a * $b}
                    '/' {if ($b -eq 0) {throw 'Division par zero.'}; $result = $a / $b}
                    default {throw 'Operation inconnue.'}
                }
                if ([double]::IsInfinity($result) -or [double]::IsNaN($result)) {throw 'Resultat non representable.'}
                $item = [ordered]@{id=[guid]::NewGuid().ToString(); date=(Get-Date).ToString('o'); a=$a; op=$op; b=$b; result=$result}
                $items = @(Read-History)
                $items += $item
                $temp = "$historyFile.tmp"
                ConvertTo-Json -InputObject @($items) -Depth 8 | Set-Content -LiteralPath $temp -Encoding UTF8
                Move-Item -LiteralPath $temp -Destination $historyFile -Force
                Send-Json $ctx 200 @{ok=$true; item=$item}
            } else { Send-Json $ctx 404 @{error='Route introuvable.'} }
        } catch {
            $message = $_.Exception.Message
            Write-Warning $message
            try { Send-Json $ctx 400 @{error=$message} } catch { try {$ctx.Response.Close()} catch {} }
        }
    }
} finally { $listener.Stop(); $listener.Close() }

$ErrorActionPreference='Stop'
Set-Location $PSScriptRoot
try {
    Add-Type -Path (Join-Path $PSScriptRoot 'Calculatrice.cs') -OutputAssembly (Join-Path $PSScriptRoot 'Calculatrice.exe') -OutputType WindowsApplication -ReferencedAssemblies @('System.dll','System.Drawing.dll','System.Windows.Forms.dll','System.Web.Extensions.dll')
    Write-Host 'Compilation reussie : Calculatrice.exe' -ForegroundColor Green
} catch { Write-Host "Compilation impossible : $_" -ForegroundColor Red; exit 1 }

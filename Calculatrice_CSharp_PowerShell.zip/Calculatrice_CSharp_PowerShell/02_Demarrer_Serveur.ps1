& (Join-Path $PSScriptRoot 'server.ps1') -Port 8090

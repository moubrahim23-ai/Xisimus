
using System;
using System.Drawing;
using System.IO;
using System.Net;
using System.Text;
using System.Windows.Forms;
using System.Web.Script.Serialization;
using System.Collections.Generic;
public class ClientForm:Form {
    TextBox a=new TextBox(),b=new TextBox(), output=new TextBox();
    ComboBox op=new ComboBox();
    string endpoint="http://127.0.0.1:8090/";
    public ClientForm(){
        Text="Client C# / Serveur PowerShell";Width=560;Height=440;StartPosition=FormStartPosition.CenterScreen;
        Label title=new Label(){Text="Test client C# → serveur PowerShell",Left=20,Top=15,Width=500,Font=new Font("Segoe UI",13,FontStyle.Bold)};Controls.Add(title);
        Button ping=new Button(){Text="Tester la connexion",Left=20,Top=55,Width=175,Height=34};ping.Click+=(s,e)=>Request("GET","ping",null);Controls.Add(ping);
        a.SetBounds(20,110,130,26);op.SetBounds(165,110,90,26);b.SetBounds(270,110,130,26);
        op.DropDownStyle=ComboBoxStyle.DropDownList;op.Items.AddRange(new object[]{"+","-","*","/"});op.SelectedIndex=0;
        Controls.Add(a);Controls.Add(op);Controls.Add(b);
        Button calculate=new Button(){Text="Calculer via serveur",Left=20,Top=155,Width=185,Height=34};
        calculate.Click+=(s,e)=>{
            double x,y;
            if(!double.TryParse(a.Text,out x)||!double.TryParse(b.Text,out y)){MessageBox.Show("Nombres invalides");return;}
            var data=new JavaScriptSerializer().Serialize(new Dictionary<string,object>{{"a",x},{"b",y},{"operation",op.Text}});
            Request("POST","calculate",data);
        };Controls.Add(calculate);
        Button history=new Button(){Text="Lire historique serveur",Left=220,Top=155,Width=200,Height=34};
        history.Click+=(s,e)=>Request("GET","history",null);Controls.Add(history);
        output.SetBounds(20,210,500,160);output.Multiline=true;output.ScrollBars=ScrollBars.Vertical;output.ReadOnly=true;Controls.Add(output);
    }
    void Request(string method,string path,string data){
        try {
            var req=(HttpWebRequest)WebRequest.Create(endpoint+path);
            req.Method=method;req.Timeout=3000;
            if(data!=null){byte[] bytes=Encoding.UTF8.GetBytes(data);req.ContentType="application/json; charset=utf-8";req.ContentLength=bytes.Length;using(var stream=req.GetRequestStream())stream.Write(bytes,0,bytes.Length);}
            using(var response=(HttpWebResponse)req.GetResponse())
            using(var reader=new StreamReader(response.GetResponseStream(),Encoding.UTF8))output.Text=reader.ReadToEnd();
        }catch(Exception ex){output.Text="Connexion impossible : "+ex.Message+"\r\nDémarrez le serveur PowerShell et vérifiez l'autorisation IT.";}
    }
    [STAThread]public static void Main(){Application.EnableVisualStyles();Application.Run(new ClientForm());}
}

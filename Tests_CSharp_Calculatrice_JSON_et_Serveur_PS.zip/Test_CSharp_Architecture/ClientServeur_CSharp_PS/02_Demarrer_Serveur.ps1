$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$prefix = 'http://127.0.0.1:8090/'
$file = Join-Path $PSScriptRoot 'historique_serveur.json'
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($prefix)
try {
    $listener.Start()
    Write-Host "Serveur local : $prefix (Ctrl+C pour arreter)" -ForegroundColor Green
    while ($listener.IsListening) {
        $ctx = $listener.GetContext()
        $res = $ctx.Response
        $res.ContentType = 'application/json; charset=utf-8'
        $res.Headers.Add('Cache-Control','no-store')
        try {
            $path = $ctx.Request.Url.AbsolutePath.Trim('/').ToLowerInvariant()
            $method = $ctx.Request.HttpMethod
            $status = 200
            if ($path -eq 'ping' -and $method -eq 'GET') {
                $response = @{ok=$true; message='Serveur PowerShell operationnel'; date=(Get-Date).ToString('s')}
            } elseif ($path -eq 'history' -and $method -eq 'GET') {
                $items = @()
                if (Test-Path $file) { $items = @(Get-Content $file -Raw -Encoding UTF8 | ConvertFrom-Json) }
                $response = @{ok=$true; historique=@($items)}
            } elseif ($path -eq 'calculate' -and $method -eq 'POST') {
                $reader = New-Object System.IO.StreamReader($ctx.Request.InputStream,[Text.Encoding]::UTF8)
                try { $body = $reader.ReadToEnd() | ConvertFrom-Json } finally { $reader.Dispose() }
                $x = [double]$body.a
                $y = [double]$body.b
                $operation = [string]$body.operation
                switch ($operation) {
                    '+' { $result = $x+$y }
                    '-' { $result = $x-$y }
                    '*' { $result = $x*$y }
                    '/' { if ($y -eq 0) { throw 'Division par zero' }; $result = $x/$y }
                    default { throw 'Operation invalide' }
                }
                if ([double]::IsNaN($result) -or [double]::IsInfinity($result)) { throw 'Resultat invalide' }
                $items = @()
                if (Test-Path $file) { $items = @(Get-Content $file -Raw -Encoding UTF8 | ConvertFrom-Json) }
                $entry = @{date=(Get-Date).ToString('s');a=$x;b=$y;operation=$operation;resultat=$result}
                $items += $entry
                ConvertTo-Json -InputObject @($items) -Depth 5 | Set-Content -Path $file -Encoding UTF8
                $response = @{ok=$true; resultat=$result; total=$items.Count}
            } else {
                $status=404
                $response=@{ok=$false; erreur='Route inconnue'}
            }
        } catch {
            $status=400
            $response=@{ok=$false; erreur=$_.Exception.Message}
        }
        $res.StatusCode=$status
        $payload=[Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $response -Depth 8 -Compress))
        $res.ContentLength64=$payload.Length
        try { $res.OutputStream.Write($payload,0,$payload.Length) } finally { $res.Close() }
    }
} finally { $listener.Stop(); $listener.Close() }

$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$source = Join-Path $PSScriptRoot 'Client.cs'
$exe = Join-Path $PSScriptRoot 'Client.exe'
if (Test-Path $exe) { Remove-Item $exe -Force }
Add-Type -Path $source -ReferencedAssemblies @('System.dll','System.Drawing.dll','System.Windows.Forms.dll','System.Web.Extensions.dll') -OutputAssembly $exe -OutputType WindowsApplication
Write-Host "Compilation reussie : $exe" -ForegroundColor Green

# Deux tests C# pour Windows

## Test 1 — Calculatrice autonome
Dossier `Calculatrice_CSharp` :
1. Ouvrir Windows PowerShell 5.1 dans le dossier.
2. Exécuter `./01_Compiler.ps1` (selon la politique d'exécution de votre organisation).
3. Exécuter `./02_Lancer.ps1`.
4. Effectuer des calculs, fermer puis rouvrir l'application.
5. Vérifier le fichier `historique.json` à côté de l'exécutable.

Aucun serveur et aucune connexion réseau nécessaires. PowerShell ne sert ici qu'à compiler et lancer le programme.

## Test 2 — Client C# et serveur PowerShell
Dossier `ClientServeur_CSharp_PS` :
1. Exécuter `./01_Compiler.ps1`.
2. Exécuter `./02_Demarrer_Serveur.ps1` et laisser cette fenêtre ouverte.
3. Dans une seconde fenêtre, exécuter `./03_Lancer_Client.ps1`.
4. Cliquer sur « Tester la connexion », puis calculer et lire l'historique.
5. Vérifier `historique_serveur.json`. Redémarrer le serveur et relire l'historique.

Le serveur écoute UNIQUEMENT sur `127.0.0.1:8090` : ce test n'est pas accessible depuis d'autres postes.

## Pré-requis et sécurité
- Windows PowerShell 5.1 et .NET Framework avec WinForms / System.Web.Extensions.
- Écriture autorisée dans le dossier d'extraction (éviter Program Files).
- Aucun téléchargement, paquet tiers ou droit administrateur n'est prévu.
- Ne pas contourner Symantec, la politique d'exécution ou une règle informatique. En cas de blocage, demander validation à l'IT.
- Les scripts n'ont pas été exécutés sur Windows dans cet environnement ; il faut valider leur compilation sur le poste cible.

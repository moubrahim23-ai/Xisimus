$exe = Join-Path $PSScriptRoot 'Calculatrice.exe'
if (-not (Test-Path $exe)) { throw 'Compilez d abord avec 01_Compiler.ps1' }
Start-Process -FilePath $exe -WorkingDirectory $PSScriptRoot

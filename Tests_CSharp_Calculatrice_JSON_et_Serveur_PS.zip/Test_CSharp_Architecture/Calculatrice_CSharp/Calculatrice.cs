
using System;
using System.IO;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Web.Script.Serialization;
using System.Globalization;

public class CalcForm : Form {
    TextBox a=new TextBox(), b=new TextBox();
    ComboBox op=new ComboBox();
    Label result=new Label();
    ListBox history=new ListBox();
    string file=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"historique.json");
    JavaScriptSerializer json=new JavaScriptSerializer();
    List<Entry> entries=new List<Entry>();
    public class Entry { public string date {get;set;} public double a {get;set;} public string operation {get;set;} public double b {get;set;} public double resultat {get;set;} }
    public CalcForm(){
        Text="Calculatrice C# - JSON local"; Width=540; Height=520; StartPosition=FormStartPosition.CenterScreen;
        Label title=new Label(){Text="Calculatrice 100 % C# (sans serveur)",Left=20,Top=15,Width=460,Height=30,Font=new Font("Segoe UI",13,FontStyle.Bold)};
        Controls.Add(title);
        a.SetBounds(20,65,135,28); b.SetBounds(310,65,135,28);
        op.SetBounds(175,65,110,28); op.DropDownStyle=ComboBoxStyle.DropDownList;
        op.Items.AddRange(new object[]{"+","-","*","/"});op.SelectedIndex=0;
        Controls.Add(a);Controls.Add(b);Controls.Add(op);
        Button compute=new Button(){Text="Calculer et enregistrer",Left=20,Top=110,Width=210,Height=36};
        compute.Click+=(s,e)=>Calculate(); Controls.Add(compute);
        result.SetBounds(250,113,250,35); result.Font=new Font("Segoe UI",12,FontStyle.Bold);Controls.Add(result);
        Label label=new Label(){Text="Historique JSON (conservé après fermeture)",Left=20,Top=165,Width=450};Controls.Add(label);
        history.SetBounds(20,190,480,235);Controls.Add(history);
        Button reload=new Button(){Text="Relire le JSON",Left=20,Top=435,Width=145};reload.Click+=(s,e)=>LoadHistory();Controls.Add(reload);
        Button folder=new Button(){Text="Ouvrir le dossier",Left=180,Top=435,Width=145};folder.Click+=(s,e)=>System.Diagnostics.Process.Start("explorer.exe",AppDomain.CurrentDomain.BaseDirectory);Controls.Add(folder);
        LoadHistory();
    }
    void LoadHistory(){
        try { entries=File.Exists(file)?json.Deserialize<List<Entry>>(File.ReadAllText(file,System.Text.Encoding.UTF8)):new List<Entry>(); if(entries==null)entries=new List<Entry>(); RefreshHistory(); }
        catch(Exception ex){MessageBox.Show("Lecture JSON impossible : "+ex.Message);}
    }
    void RefreshHistory(){history.Items.Clear();foreach(Entry x in entries)history.Items.Add(x.date+" | "+x.a+" "+x.operation+" "+x.b+" = "+x.resultat);}
    void Calculate(){
        double x,y;
        if(!double.TryParse(a.Text,NumberStyles.Float,CultureInfo.CurrentCulture,out x) || !double.TryParse(b.Text,NumberStyles.Float,CultureInfo.CurrentCulture,out y)){MessageBox.Show("Saisissez deux nombres valides.");return;}
        string operation=op.Text;
        if(operation=="/" && y==0){MessageBox.Show("Division par zéro interdite.");return;}
        double r=operation=="+"?x+y:operation=="-"?x-y:operation=="*"?x*y:x/y;
        if(double.IsNaN(r)||double.IsInfinity(r)){MessageBox.Show("Résultat non valide.");return;}
        entries.Add(new Entry(){date=DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),a=x,b=y,operation=operation,resultat=r});
        try {File.WriteAllText(file,json.Serialize(entries),System.Text.Encoding.UTF8);result.Text="Résultat : "+r;RefreshHistory();}
        catch(Exception ex){entries.RemoveAt(entries.Count-1);MessageBox.Show("Écriture JSON impossible : "+ex.Message);}
    }
    [STAThread] public static void Main(){Application.EnableVisualStyles();Application.Run(new CalcForm());}
}

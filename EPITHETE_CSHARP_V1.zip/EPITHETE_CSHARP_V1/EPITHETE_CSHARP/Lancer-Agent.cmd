@echo off
setlocal
if not exist "%~dp0bin\EPITHETE-Agent.exe" (
  echo EXE absent. Utilisez le ZIP complet ou Compiler.ps1.
  pause
  exit /b 1
)
start "EPITHETE Agent" "%~dp0bin\EPITHETE-Agent.exe"
endlocal

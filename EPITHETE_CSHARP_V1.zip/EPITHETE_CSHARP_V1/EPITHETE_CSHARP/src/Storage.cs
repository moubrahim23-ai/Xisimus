using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace EpitheteDesktop
{
    internal static class JsonData
    {
        public static JToken Parse(string text)
        {
            using (var reader = new JsonTextReader(new StringReader(text.TrimStart('\uFEFF'))))
            {
                reader.DateParseHandling = DateParseHandling.None;
                reader.FloatParseHandling = FloatParseHandling.Decimal;
                reader.MaxDepth = 128;
                JToken result = JToken.Load(reader, new JsonLoadSettings { DuplicatePropertyNameHandling = DuplicatePropertyNameHandling.Error });
                while (reader.Read()) if (reader.TokenType != JsonToken.Comment) throw new InvalidDataException("Contenu JSON supplementaire inattendu.");
                return result;
            }
        }
        public static string Text(JToken value) { return value == null || value.Type == JTokenType.Null ? "" : value.Type == JTokenType.String ? (string)value : value.ToString(Formatting.None); }
        public static string Field(JObject row, string key) { return Text(row[key]); }
        public static JObject Obj(params object[] pairs)
        {
            var result = new JObject();
            for (int i = 0; i < pairs.Length; i += 2)
            {
                object value = pairs[i + 1];
                result[(string)pairs[i]] = value == null ? JValue.CreateNull() : value is JToken ? ((JToken)value).DeepClone() : JToken.FromObject(value);
            }
            return result;
        }
        public static string Now() { return DateTimeOffset.Now.ToString("o", CultureInfo.InvariantCulture); }
        public static string Normalize(string value)
        {
            var builder = new StringBuilder();
            foreach (char c in (value ?? "").Normalize(NormalizationForm.FormD))
                if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark) builder.Append(c);
            return System.Text.RegularExpressions.Regex.Replace(builder.ToString().ToLowerInvariant(), @"\s+", " ").Trim();
        }
        public static JArray Array(JToken token)
        {
            if (token == null || token.Type == JTokenType.Null) return new JArray();
            return token is JArray ? (JArray)token : new JArray(token.DeepClone());
        }
    }

    internal static class AtomicFile
    {
        public static void Write(string path, byte[] bytes)
        {
            string temp = Path.Combine(Path.GetDirectoryName(path), ".epithete-" + Guid.NewGuid().ToString("N") + ".tmp");
            try
            {
                using (var file = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                { file.Write(bytes, 0, bytes.Length); file.Flush(true); }
                if (File.Exists(path)) File.Replace(temp, path, path + ".bak", true);
                else File.Move(temp, path);
            }
            finally { if (File.Exists(temp)) File.Delete(temp); }
        }
    }

    internal sealed class FileStore
    {
        public const string DefaultDataDirectory = @"\\uf11-A02\EIDS_EPITHETE_BO_CONSEILLERS\Epithéte\data";
        public const string DefaultSourceDirectory = @"\\uf11-A02\EIDS_EPITHETE_BO_MANAGERS\ETAFAC\Source";
        public readonly string DirectoryPath;
        public string DatabasePath { get { return Path.Combine(DirectoryPath, "epithete-traitements.json"); } }
        public string ConfigPath { get { return Path.Combine(DirectoryPath, "epithete-config.json"); } }
        public FileStore(string directory)
        {
            if (String.IsNullOrWhiteSpace(directory)) throw new ArgumentException("Dossier de donnees obligatoire.");
            DirectoryPath = Path.GetFullPath(directory);
        }
        public T Locked<T>(Func<T> action)
        {
            if (!Directory.Exists(DirectoryPath)) throw new DirectoryNotFoundException("Dossier de donnees inaccessible : " + DirectoryPath + ". Verifiez desktop-config.json et vos droits sur le DP.");
            FileStream handle = null;
            for (int i = 0; i < 80 && handle == null; i++)
            {
                try { handle = new FileStream(Path.Combine(DirectoryPath, "epithete.verrou"), FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None); }
                catch (IOException) { if (i == 79) throw new IOException("Donnees occupees. Reessayez dans quelques secondes."); Thread.Sleep(100); }
            }
            using (handle) return action();
        }
        public List<JObject> ReadRecords()
        {
            if (!File.Exists(DatabasePath)) throw new FileNotFoundException("Base introuvable. Aucun JSON vide n'a ete cree. Verifiez le dossier de donnees.", DatabasePath);
            JToken token = Read(DatabasePath);
            var rows = new List<JObject>(); Flatten(token, rows);
            var ids = new HashSet<string>(StringComparer.Ordinal);
            foreach (JObject row in rows)
            {
                string id = JsonData.Field(row, "id");
                if (String.IsNullOrEmpty(id) || !ids.Add(id)) throw new InvalidDataException("Base invalide : identifiant absent ou duplique. Aucune modification effectuee.");
            }
            return rows;
        }
        private static void Flatten(JToken token, List<JObject> rows)
        {
            var array = token as JArray;
            if (array != null) { foreach (JToken item in array) Flatten(item, rows); return; }
            var row = token as JObject;
            if (row == null) throw new InvalidDataException("La base doit contenir des objets JSON dans un tableau.");
            rows.Add(row);
        }
        public JObject ReadConfig()
        {
            if (!File.Exists(ConfigPath)) return JsonData.Obj("sourceDirectory", DefaultSourceDirectory, "agents", new JArray());
            var config = Read(ConfigPath) as JObject;
            if (config == null) throw new InvalidDataException("Configuration JSON invalide.");
            if (config["agents"] == null) config["agents"] = new JArray();
            return config;
        }
        public static JToken Read(string path)
        {
            string text = File.ReadAllText(path, new UTF8Encoding(false, true));
            if (String.IsNullOrWhiteSpace(text)) throw new InvalidDataException("Fichier JSON vide : " + Path.GetFileName(path) + ". Aucune modification effectuee.");
            return JsonData.Parse(text);
        }
        public void SaveRecords(List<JObject> rows) { Write(DatabasePath, new JArray(rows)); }
        public void SaveConfig(JObject config) { Write(ConfigPath, config); }
        private static void Write(string path, JToken value) { AtomicFile.Write(path, new UTF8Encoding(false).GetBytes(value.ToString(Formatting.Indented) + Environment.NewLine)); }
    }
}

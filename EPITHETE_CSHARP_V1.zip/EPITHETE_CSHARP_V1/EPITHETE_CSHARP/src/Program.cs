using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows;
using System.Windows.Threading;
using Microsoft.Win32;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.Wpf;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using D = EpitheteDesktop.JsonData;

namespace EpitheteDesktop
{
    internal static class Program
    {
#if MANAGER
        public static readonly bool Manager = true;
#else
        public static readonly bool Manager = false;
#endif
        [STAThread]
        private static void Main()
        {
            try
            {
                var app = new Application();
                app.DispatcherUnhandledException += delegate(object s, DispatcherUnhandledExceptionEventArgs e)
                { MessageBox.Show(e.Exception.Message, "ÉPITHÈTE", MessageBoxButton.OK, MessageBoxImage.Error); e.Handled = true; };
                app.Run(new MainWindow());
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "ÉPITHÈTE — demarrage impossible", MessageBoxButton.OK, MessageBoxImage.Error); }
        }
    }
    internal sealed class MainWindow : Window
    {
        private readonly WebView2 view = new WebView2();
        private readonly StaWorker worker = new StaWorker();
        private readonly DispatcherTimer timer = new DispatcherTimer();
        private LocalPolicy policy;
        private InvoiceService service;
        private bool starting, ready, closingCheck;
        private int operations;
        private string navigation = "En attente";
        private string sessionDirectory;
        public MainWindow()
        {
            Title = Program.Manager ? "ÉPITHÈTE · ÉTAT FAC — Manager" : "ÉPITHÈTE · ÉTAT FAC — Agent";
            Rect zone = SystemParameters.WorkArea;
            Width = Math.Min(1200, zone.Width - 40); Height = Math.Min(720, zone.Height - 40);
            MinWidth = Math.Min(800, Width); MinHeight = Math.Min(500, Height);
            WindowStartupLocation = WindowStartupLocation.Manual;
            Left = zone.Left + (zone.Width - Width) / 2; Top = zone.Top + (zone.Height - Height) / 2;
            Content = view; Loaded += Start; Closing += CheckClose;
            Closed += delegate
            {
                timer.Stop(); view.Dispose(); worker.Dispose();
                if (sessionDirectory != null)
                    try { Directory.Delete(sessionDirectory, true); } catch { /* Cache technique eventuellement verrouille. */ }
            };
        }
        private static string DataDirectory()
        {
            string config = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "desktop-config.json");
            if (!File.Exists(config)) config = Path.Combine(Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar)), "desktop-config.json");
            if (!File.Exists(config)) return FileStore.DefaultDataDirectory;
            var value = FileStore.Read(config) as JObject;
            string directory = value == null ? "" : D.Field(value, "dataDirectory");
            if (String.IsNullOrWhiteSpace(directory)) throw new InvalidDataException("desktop-config.json : dataDirectory obligatoire.");
            return Path.IsPathRooted(directory) ? directory : Path.GetFullPath(Path.Combine(Path.GetDirectoryName(config), directory));
        }
        private string ExtractInterface()
        {
            sessionDirectory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "EpitheteDesktop", "Sessions", Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(sessionDirectory);
            Assembly assembly = Assembly.GetExecutingAssembly();
            foreach (string resource in assembly.GetManifestResourceNames().Where(n => n.StartsWith("Epithete.UI.", StringComparison.Ordinal)))
            {
                string name = resource.Substring("Epithete.UI.".Length);
                if (Path.GetFileName(name) != name) throw new InvalidDataException("Nom de ressource invalide.");
                string path = Path.Combine(sessionDirectory, name);
                using (Stream input = assembly.GetManifestResourceStream(resource))
                using (var output = new FileStream(path, FileMode.CreateNew)) input.CopyTo(output);
            }
            string index = Path.Combine(sessionDirectory, "index.html");
            string html = File.ReadAllText(index, Encoding.UTF8);
            const string csp = "<meta http-equiv=\"Content-Security-Policy\" content=\"default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src data: blob:; font-src data:; connect-src 'none'; worker-src blob:; frame-src 'none'; object-src 'none'; form-action 'none'; base-uri 'none'\">";
            html = html.Replace("<meta charset=\"utf-8\">", "<meta charset=\"utf-8\">" + csp);
            File.WriteAllText(index, html, new UTF8Encoding(false));
            string document = new Uri(index).AbsoluteUri;
            policy = new LocalPolicy(document, Directory.GetFiles(sessionDirectory).Select(p => new Uri(p).AbsoluteUri));
            return document;
        }
        private async void Start(object sender, RoutedEventArgs args)
        {
            if (starting) return; starting = true; Loaded -= Start;
            try
            {
                var store = new FileStore(DataDirectory());
                service = new InvoiceService(store, Program.Manager, Environment.UserName, new ExcelFiles());
                string document = ExtractInterface();
                string profile = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "EpitheteDesktop", "WebView2", Guid.NewGuid().ToString("N"));
                var environment = await CoreWebView2Environment.CreateAsync(null, profile);
                await view.EnsureCoreWebView2Async(environment);
                var core = view.CoreWebView2;
                core.Settings.IsWebMessageEnabled = true; core.Settings.AreHostObjectsAllowed = false;
                core.Settings.AreDevToolsEnabled = false; core.Settings.AreDefaultContextMenusEnabled = false;
                core.Settings.AreBrowserAcceleratorKeysEnabled = false; core.Settings.IsStatusBarEnabled = false;
                core.Settings.IsGeneralAutofillEnabled = false; core.Settings.IsPasswordAutosaveEnabled = false;
                core.NavigationStarting += delegate(object s, CoreWebView2NavigationStartingEventArgs e) { if (!policy.Document(e.Uri)) e.Cancel = true; };
                core.NewWindowRequested += delegate(object s, CoreWebView2NewWindowRequestedEventArgs e) { e.Handled = true; };
                core.PermissionRequested += delegate(object s, CoreWebView2PermissionRequestedEventArgs e) { e.State = CoreWebView2PermissionState.Deny; };
                core.DownloadStarting += delegate(object s, CoreWebView2DownloadStartingEventArgs e) { e.Cancel = true; };
                core.AddWebResourceRequestedFilter("*", CoreWebView2WebResourceContext.All);
                core.WebResourceRequested += delegate(object s, CoreWebView2WebResourceRequestedEventArgs e)
                {
                    if (!policy.Resource(e.Request.Uri)) e.Response = environment.CreateWebResourceResponse(new MemoryStream(new byte[0]), 403, "Blocked", "Content-Type: text/plain");
                };
                core.WebMessageReceived += Receive;
                core.NavigationCompleted += delegate(object s, CoreWebView2NavigationCompletedEventArgs e) { navigation = e.IsSuccess ? "Document charge" : e.WebErrorStatus.ToString(); };
                core.ProcessFailed += delegate { MessageBox.Show(this, "Le moteur d'affichage s'est arrete. Fermez et relancez l'application. Les traitements deja enregistres restent dans le JSON central.", "ÉPITHÈTE"); };
                timer.Interval = TimeSpan.FromSeconds(20);
                timer.Tick += delegate { timer.Stop(); if (!ready) MessageBox.Show(this, "L'interface locale n'a pas confirme son demarrage. Etat : " + navigation, "ÉPITHÈTE — diagnostic"); };
                timer.Start(); core.Navigate(document);
            }
            catch (WebView2RuntimeNotFoundException)
            { MessageBox.Show(this, "Le runtime Microsoft Edge WebView2 est absent. Aucune installation automatique n'est lancee. Contactez votre service informatique.", "ÉPITHÈTE"); Close(); }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "ÉPITHÈTE — demarrage impossible"); Close(); }
        }
        private void Reply(string id, bool ok, object value)
        {
            var message = D.Obj("id", id, "ok", ok, ok ? "result" : "error", value);
            view.CoreWebView2.PostWebMessageAsJson(message.ToString(Formatting.None));
        }
        private async void Receive(object sender, CoreWebView2WebMessageReceivedEventArgs e)
        {
            if (policy == null || !policy.Document(e.Source)) return;
            string id = ""; bool close = false;
            try
            {
                var m = D.Parse(e.WebMessageAsJson) as JObject;
                if (m == null) return;
                string command = D.Field(m, "command");
                if (command == "ready") { ready = true; timer.Stop(); return; }
                id = D.Field(m, "id");
                if (id.Length == 0 || id.Length > 64) return;
                if (closingCheck) { Reply(id, false, "Fermeture en cours."); return; }
                var body = m["body"] as JObject ?? new JObject();
                operations++;
                try
                {
                    object result;
                    if (command == "clipboard") result = Copy(body);
                    else if (command == "saveDocument")
                    {
                        if (!Program.Manager) throw new InvalidOperationException("Export reserve a l'espace Manager.");
                        result = await SaveDocument(body);
                    }
                    else if (command == "shutdown") { result = D.Obj("ok", true); close = true; }
                    else result = await worker.Run(delegate { return service.Execute(command, body); });
                    Reply(id, true, result);
                }
                finally { operations--; }
            }
            catch (Exception ex) { if (id.Length > 0) Reply(id, false, ex.Message); }
            if (close) await Dispatcher.InvokeAsync(new Action(Close));
        }
        private JObject Copy(JObject body)
        {
            string text = D.Field(body, "text"), html = D.Field(body, "html");
            var data = new DataObject(); data.SetData(DataFormats.UnicodeText, text);
            if (html.Length > 0) data.SetData(DataFormats.Html, HtmlClipboard(html));
            Clipboard.SetDataObject(data, true); return D.Obj("ok", true);
        }
        private static string HtmlClipboard(string fragment)
        {
            const string format = "Version:0.9\r\nStartHTML:{0:0000000000}\r\nEndHTML:{1:0000000000}\r\nStartFragment:{2:0000000000}\r\nEndFragment:{3:0000000000}\r\n";
            const string prefix = "<html><body><!--StartFragment-->";
            const string suffix = "<!--EndFragment--></body></html>";
            int start = Encoding.UTF8.GetByteCount(String.Format(CultureInfo.InvariantCulture, format, 0, 0, 0, 0));
            int fragmentStart = start + Encoding.UTF8.GetByteCount(prefix), fragmentEnd = fragmentStart + Encoding.UTF8.GetByteCount(fragment);
            int end = fragmentEnd + Encoding.UTF8.GetByteCount(suffix);
            return String.Format(CultureInfo.InvariantCulture, format, start, end, fragmentStart, fragmentEnd) + prefix + fragment + suffix;
        }
        private async System.Threading.Tasks.Task<JObject> SaveDocument(JObject body)
        {
            string name = Path.GetFileName(D.Field(body, "name")), ext = Path.GetExtension(name).ToLowerInvariant();
            if (ext != ".pdf" && ext != ".pptx") throw new InvalidDataException("Format d'export non autorise.");
            string encoded = D.Field(body, "base64");
            if (encoded.Length > 70 * 1024 * 1024) throw new IOException("Export trop volumineux (50 Mio maximum).");
            byte[] bytes = Convert.FromBase64String(encoded);
            if (bytes.Length > 50 * 1024 * 1024) throw new IOException("Export trop volumineux (50 Mio maximum).");
            if (bytes.Length < 5 || (ext == ".pdf" ? Encoding.ASCII.GetString(bytes, 0, 5) != "%PDF-" : bytes[0] != 80 || bytes[1] != 75)) throw new InvalidDataException("Contenu d'export invalide.");
            var dialog = new SaveFileDialog { FileName = name, DefaultExt = ext, AddExtension = true, OverwritePrompt = true, Filter = ext == ".pdf" ? "PDF (*.pdf)|*.pdf" : "PowerPoint (*.pptx)|*.pptx" };
            if (dialog.ShowDialog(this) != true) return D.Obj("cancelled", true);
            string target = dialog.FileName;
            await worker.Run(delegate { AtomicFile.Write(target, bytes); return true; });
            return D.Obj("ok", true, "path", target);
        }
        private async void CheckClose(object sender, CancelEventArgs e)
        {
            if (operations > 0) { e.Cancel = true; MessageBox.Show(this, "Une operation est en cours. Attendez sa fin avant de fermer.", "ÉPITHÈTE"); return; }
            if (!ready || view.CoreWebView2 == null) return;
            e.Cancel = true; if (closingCheck) return; closingCheck = true;
            try
            {
                string draft = await view.ExecuteScriptAsync("Boolean(window.EpitheteHasDraft && window.EpitheteHasDraft())");
                if (draft == "true" && MessageBox.Show(this, "Une saisie n'est pas enregistree. Fermer et l'abandonner ?", "ÉPITHÈTE", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
                Closing -= CheckClose; Close();
            }
            catch
            {
                if (MessageBox.Show(this, "Impossible de verifier la saisie. Fermer quand meme ?", "ÉPITHÈTE", MessageBoxButton.YesNo) == MessageBoxResult.Yes) { Closing -= CheckClose; Close(); }
            }
            finally { closingCheck = false; }
        }
    }
}

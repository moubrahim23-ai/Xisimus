using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Newtonsoft.Json.Linq;
using D = EpitheteDesktop.JsonData;

namespace EpitheteDesktop
{
    internal sealed class ScanResult
    {
        public readonly List<JObject> Rows = new List<JObject>();
        public readonly List<string> Errors = new List<string>();
        public int Files;
        public int Duplicates;
    }
    internal sealed class ExportResult
    {
        public readonly List<JObject> Saved = new List<JObject>();
        public readonly List<string> Errors = new List<string>();
        public int Files;
    }
    internal interface IExcelFiles
    {
        ScanResult Scan(string directory, string user);
        ExportResult Export(List<JObject> rows);
    }
    internal sealed class InvoiceService
    {
        private readonly FileStore store;
        private readonly bool manager;
        private readonly string user;
        private readonly IExcelFiles excel;
        public InvoiceService(FileStore store, bool manager, string user, IExcelFiles excel)
        { this.store = store; this.manager = manager; this.user = user; this.excel = excel; }
        public JObject Execute(string command, JObject body)
        {
            body = body ?? new JObject();
            if (command == "state") return store.Locked(State);
            if (manager && command == "import") return Import();
            if (manager && command == "export") return Export();
            return store.Locked(delegate { return manager ? Manager(command, body) : Agent(command, body); });
        }
        private JObject State()
        {
            List<JObject> rows = store.ReadRecords();
            if (!manager) return D.Obj("application", "EPITHETE AGENT", "version", "CSharp-1.0", "collaborateur", user,
                "traitements", new JArray(rows.Where(Own)), "actualiseLe", D.Now());
            JObject cfg = store.ReadConfig();
            var agents = D.Array(cfg["agents"]).Select(D.Text).Concat(rows.Select(r => D.Field(r, "agent")))
                .Where(n => !String.IsNullOrWhiteSpace(n)).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(n => n, StringComparer.OrdinalIgnoreCase);
            return D.Obj("application", "EPITHETE MANAGER", "version", "CSharp-1.0", "collaborateur", user, "config", cfg,
                "agents", new JArray(agents), "traitements", new JArray(rows), "actualiseLe", D.Now());
        }
        private bool Own(JObject row) { return String.Equals(D.Field(row, "agent"), user, StringComparison.OrdinalIgnoreCase); }
        private static bool Has(JObject row, string field) { return !String.IsNullOrEmpty(D.Field(row, field)); }
        private static void Journal(JObject row, string user, string action, string detail)
        {
            var history = new JArray(D.Array(row["journal"]).Select(t => t.DeepClone()));
            history.Add(D.Obj("date", D.Now(), "auteur", user, "action", action, "detail", detail)); row["journal"] = history;
        }
        private JObject Agent(string command, JObject body)
        {
            if (!new[] { "start", "finish", "update" }.Contains(command)) throw new InvalidOperationException("Action non autorisee dans l'espace Agent.");
            List<JObject> rows = store.ReadRecords();
            JObject row = rows.FirstOrDefault(r => D.Field(r, "id") == D.Field(body, "id"));
            if (row == null) throw new InvalidOperationException("Ligne introuvable.");
            if (!Own(row)) throw new InvalidOperationException("Cette ligne est affectee a un autre agent.");
            string now = D.Now();
            if (command == "start")
            {
                if (Has(row, "datePriseEnCharge") || Has(row, "dateFin")) throw new InvalidOperationException("Cette ligne ne peut pas etre demarree.");
                if (rows.Any(r => Own(r) && Has(r, "datePriseEnCharge") && !Has(r, "dateFin"))) throw new InvalidOperationException("Vous avez deja un traitement en cours.");
                row["statut"] = "EN_COURS"; row["datePriseEnCharge"] = now;
                Journal(row, user, "Prise en charge", D.Field(row, "raisonSociale"));
            }
            else
            {
                bool update = command == "update";
                if (update && !Has(row, "dateFin")) throw new InvalidOperationException("Seul un traitement termine peut etre modifie.");
                if (!update && (!Has(row, "datePriseEnCharge") || Has(row, "dateFin"))) throw new InvalidOperationException("Traitement non demarre ou deja termine.");
                string state = D.Field(body, "etatTraitement").Trim();
                if (state.Length == 0) throw new InvalidOperationException("Etat du traitement est obligatoire.");
                if (state.Length > 500) throw new InvalidOperationException("Etat du traitement est trop long (500 caracteres maximum).");
                row["etatTraitement"] = state;
                if (update)
                {
                    row["dateModification"] = now; row["dateExport"] = JValue.CreateNull();
                    Journal(row, user, "Modification agent", D.Field(row, "raisonSociale"));
                }
                else
                {
                    DateTimeOffset started;
                    if (!DateTimeOffset.TryParse(D.Field(row, "datePriseEnCharge"), CultureInfo.InvariantCulture, DateTimeStyles.None, out started)) throw new InvalidOperationException("Date de prise en charge invalide.");
                    double seconds = Math.Max(0, Math.Floor((DateTimeOffset.Parse(now, CultureInfo.InvariantCulture) - started).TotalSeconds));
                    row["dmtSecondes"] = seconds; row["dateFin"] = now; row["statut"] = "TERMINE";
                    Journal(row, user, "Traitement terminé", "DMT " + seconds.ToString(CultureInfo.InvariantCulture) + " secondes");
                }
            }
            store.SaveRecords(rows); return D.Obj("ok", true);
        }
        private JObject Manager(string command, JObject body)
        {
            if (command == "config")
            {
                string path = D.Field(body, "sourceDirectory").Trim();
                if (path.Length == 0) throw new InvalidOperationException("Chemin source obligatoire.");
                JObject cfg = store.ReadConfig(); cfg["sourceDirectory"] = path; store.SaveConfig(cfg); return D.Obj("ok", true);
            }
            if (command == "agents")
            {
                string name = D.Field(body, "name").Trim().ToUpperInvariant();
                if (name.Length == 0 || name.Length > 256) throw new InvalidOperationException("Nom de session agent invalide.");
                JObject cfg = store.ReadConfig(); cfg["agents"] = new JArray(D.Array(cfg["agents"]).Select(D.Text).Concat(new[] { name }).Where(n => n.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(n => n));
                store.SaveConfig(cfg); return D.Obj("ok", true, "name", name);
            }
            if (command == "assign")
            {
                string agent = D.Field(body, "agent").Trim();
                if (agent.Length == 0 || agent.Length > 256) throw new InvalidOperationException("Nom de l'agent obligatoire.");
                var ids = new HashSet<string>(D.Array(body["ids"]).Select(D.Text), StringComparer.Ordinal);
                List<JObject> rows = store.ReadRecords(); int count = 0;
                foreach (JObject row in rows.Where(r => ids.Contains(D.Field(r, "id")) && !Has(r, "agent") && !Has(r, "dateFin")))
                {
                    row["agent"] = agent; row["statut"] = "Affecté"; row["dateAffectation"] = D.Now();
                    Journal(row, user, "Affectation", agent); count++;
                }
                if (count > 0) store.SaveRecords(rows);
                return D.Obj("ok", true, "affectees", count);
            }
            throw new InvalidOperationException("Action Manager inconnue.");
        }
        private JObject Import()
        {
            string directory = store.Locked(delegate { return D.Field(store.ReadConfig(), "sourceDirectory"); });
            // Le scan Excel ne monopolise pas le verrou central. Fusion avec les donnees les plus recentes ensuite.
            ScanResult scan = excel.Scan(directory, user);
            return store.Locked(delegate
            {
                List<JObject> rows = store.ReadRecords();
                var known = new Dictionary<string, JObject>(StringComparer.OrdinalIgnoreCase);
                foreach (JObject row in rows.Where(r => Has(r, "numeroFacture"))) known[Key(row)] = row;
                int added = 0;
                foreach (JObject candidate in scan.Rows)
                {
                    JObject previous;
                    if (known.TryGetValue(Key(candidate), out previous))
                    {
                        if ((bool?)candidate["_hasSourceMotif"] == true)
                        {
                            string motif = D.Field(candidate, "motif"); previous["motif"] = motif;
                            foreach (JObject cell in D.Array(previous["sourceValues"]).OfType<JObject>())
                                if (new[] { "motif", "code motif" }.Contains(D.Normalize(D.Field(cell, "label")))) { cell["text"] = motif; cell["value"] = motif; }
                        }
                    }
                    else
                    {
                        candidate.Remove("_hasSourceMotif"); rows.Add(candidate); known[Key(candidate)] = candidate; added++;
                    }
                }
                store.SaveRecords(rows);
                return D.Obj("ok", true, "ajoutees", added, "fichiers", scan.Files, "doublonsIgnores", scan.Duplicates, "erreurs", new JArray(scan.Errors));
            });
        }
        private static string Key(JObject row) { return D.Field(row, "sourcePath") + "|FACTURE|" + D.Field(row, "numeroFacture").Trim(); }
        private JObject Export()
        {
            List<JObject> snapshot = store.Locked(delegate { return store.ReadRecords().Where(r => Has(r, "dateFin") && Has(r, "numeroFacture") && Has(r, "sourcePath") && Has(r, "sourceSheet")).ToList(); });
            if (snapshot.Count == 0) throw new InvalidOperationException("Aucune facture terminee a exporter.");
            ExportResult result = excel.Export(snapshot);
            return store.Locked(delegate
            {
                List<JObject> rows = store.ReadRecords(); var byId = rows.ToDictionary(r => D.Field(r, "id")); int marked = 0;
                foreach (JObject saved in result.Saved)
                {
                    JObject current;
                    if (!byId.TryGetValue(D.Field(saved, "id"), out current)) continue;
                    if (new[] { "etatTraitement", "dateFin", "dateModification" }.All(k => D.Field(saved, k) == D.Field(current, k)))
                    { current["dateExport"] = D.Now(); marked++; }
                    else result.Errors.Add("Une facture a ete modifiee pendant l'export ; reexportez la derniere saisie.");
                }
                if (marked > 0) store.SaveRecords(rows);
                return D.Obj("ok", true, "exportees", result.Saved.Count, "fichiers", result.Files, "erreurs", new JArray(result.Errors));
            });
        }
    }
}

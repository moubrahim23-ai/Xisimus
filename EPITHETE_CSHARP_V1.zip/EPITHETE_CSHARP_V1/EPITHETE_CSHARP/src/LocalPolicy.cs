using System;
using System.Collections.Generic;
using System.Linq;
namespace EpitheteDesktop
{
    internal sealed class LocalPolicy
    {
        private readonly string document;
        private readonly HashSet<string> assets;
        public LocalPolicy(string document, IEnumerable<string> assets)
        { this.document = Canonical(document); this.assets = new HashSet<string>(assets.Select(Canonical), StringComparer.OrdinalIgnoreCase); }
        private static string Canonical(string value)
        {
            Uri uri;
            if (!Uri.TryCreate(value, UriKind.Absolute, out uri) || !uri.IsFile || uri.IsUnc || uri.Host.Length > 0 || uri.Query.Length > 0) return null;
            var b = new UriBuilder(uri); b.Fragment = ""; return b.Uri.AbsoluteUri;
        }
        public bool Document(string value) { string key = Canonical(value); return key != null && String.Equals(document, key, StringComparison.OrdinalIgnoreCase); }
        public bool Resource(string value) { string key = Canonical(value); return key != null && assets.Contains(key); }
    }
}

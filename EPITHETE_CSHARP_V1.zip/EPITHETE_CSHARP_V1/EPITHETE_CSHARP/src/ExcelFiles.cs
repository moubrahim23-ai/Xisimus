using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using Newtonsoft.Json.Linq;
using D = EpitheteDesktop.JsonData;

namespace EpitheteDesktop
{
    internal sealed class ExcelFiles : IExcelFiles
    {
        private static void Release(object value) { if (value != null && Marshal.IsComObject(value)) Marshal.FinalReleaseComObject(value); }
        private sealed class ExcelSession : IDisposable
        {
            public dynamic App;
            public dynamic Books;
            public ExcelSession()
            {
                Type type = Type.GetTypeFromProgID("Excel.Application");
                if (type == null) throw new InvalidOperationException("Excel de bureau doit etre installe pour l'import/export, comme dans la version PowerShell.");
                try
                {
                    App = Activator.CreateInstance(type); App.Visible = false; App.DisplayAlerts = false;
                    // Restriction des macros sur cette instance uniquement, jamais de modification globale.
                    App.AutomationSecurity = 3; App.AskToUpdateLinks = false; Books = App.Workbooks;
                }
                catch { Dispose(); throw; }
            }
            public dynamic Open(string path, bool readOnly) { return Books.Open(path, 0, readOnly); }
            public void Dispose()
            {
                try { if (App != null) App.Quit(); }
                finally { Release((object)Books); Release((object)App); Books = null; App = null; }
            }
        }
        private sealed class Sheet : IDisposable
        {
            public dynamic Native;
            private dynamic cells;
            public Sheet(object sheet) { Native = sheet; cells = Native.Cells; }
            public string Name { get { return Convert.ToString(Native.Name, CultureInfo.InvariantCulture); } }
            public JObject ReadCell(int row, int col, string label)
            {
                dynamic cell = cells.Item(row, col);
                try
                {
                    object raw = cell.Value2;
                    return D.Obj("column", col, "label", label, "text", Convert.ToString(cell.Text, CultureInfo.InvariantCulture).Trim(),
                        "value", raw, "numberFormat", Convert.ToString(cell.NumberFormat, CultureInfo.InvariantCulture));
                }
                finally { Release((object)cell); }
            }
            public string Text(int row, int col)
            {
                dynamic cell = cells.Item(row, col);
                try { return Convert.ToString(cell.Text, CultureInfo.InvariantCulture).Trim(); }
                finally { Release((object)cell); }
            }
            public void SetText(int row, int col, string value)
            {
                dynamic cell = cells.Item(row, col);
                try { cell.NumberFormat = "@"; cell.Value2 = value; }
                finally { Release((object)cell); }
            }
            public int[] Bounds()
            {
                dynamic used = Native.UsedRange; dynamic rows = null, cols = null;
                try { rows = used.Rows; cols = used.Columns; return new[] { (int)used.Row + (int)rows.Count - 1, (int)used.Column + (int)cols.Count - 1 }; }
                finally { Release((object)cols); Release((object)rows); Release((object)used); }
            }
            public void Dispose() { Release((object)cells); Release((object)Native); cells = null; Native = null; }
        }
        private sealed class Header
        {
            public int Row, LastRow, LastCol, Number, Motif, State;
            public readonly List<KeyValuePair<int, string>> Columns = new List<KeyValuePair<int, string>>();
        }
        private static Header FindHeader(Sheet sheet)
        {
            int[] bounds = sheet.Bounds();
            for (int r = 1; r <= Math.Min(bounds[0], 60); r++)
            {
                var h = new Header { Row = r, LastRow = bounds[0], LastCol = bounds[1] };
                for (int c = 1; c <= bounds[1]; c++)
                {
                    string label = sheet.Text(r, c), normalized = D.Normalize(label);
                    h.Columns.Add(new KeyValuePair<int, string>(c, label));
                    if (new[] { "numero", "numero de facture", "n° facture", "n° de facture" }.Contains(normalized)) h.Number = c;
                    if (normalized == "code motif" || (normalized == "motif" && h.Motif == 0)) h.Motif = c;
                    if (System.Text.RegularExpressions.Regex.IsMatch(normalized, @"^etat (du |de )?traitement")) h.State = c;
                }
                if (h.Number > 0) return h;
            }
            return null;
        }
        private sealed class Candidate { public int Index; public Header Header; }
        public ScanResult Scan(string directory, string user)
        {
            if (!Directory.Exists(directory)) throw new DirectoryNotFoundException("Dossier source introuvable : " + directory);
            string[] files = Directory.GetFiles(directory).Where(f => new[] { ".xlsx", ".xlsm", ".xls" }.Contains(Path.GetExtension(f).ToLowerInvariant()) && !Path.GetFileName(f).StartsWith("~$")).OrderBy(f => f).ToArray();
            if (files.Length == 0) throw new InvalidOperationException("Aucun fichier Excel trouve dans le dossier source.");
            var result = new ScanResult { Files = files.Length };
            using (var excel = new ExcelSession())
                foreach (string file in files)
                {
                    dynamic book = null, sheets = null;
                    try
                    {
                        book = excel.Open(file, true); sheets = book.Worksheets;
                        var candidates = new List<Candidate>();
                        for (int i = 1; i <= (int)sheets.Count; i++)
                            using (var sheet = new Sheet(sheets.Item(i)))
                            { Header h = FindHeader(sheet); if (h != null) candidates.Add(new Candidate { Index = i, Header = h }); }
                        if (candidates.Count == 0) { result.Errors.Add("En-tete Numero introuvable dans " + Path.GetFileName(file)); continue; }
                        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                        foreach (Candidate candidate in candidates.OrderByDescending(c => (c.Header.Motif > 0 ? 1 : 0) + (c.Header.State > 0 ? 1 : 0)))
                            using (var sheet = new Sheet(sheets.Item(candidate.Index)))
                            {
                                Header h = candidate.Header;
                                for (int r = h.Row + 1; r <= h.LastRow; r++)
                                {
                                    string number = sheet.Text(r, h.Number);
                                    if (number.Length == 0) continue;
                                    if (!seen.Add(number)) { result.Duplicates++; continue; }
                                    var cells = new JArray(); string client = "", type = "", motif = "", state = "";
                                    foreach (var column in h.Columns.Where(c => c.Value.Length > 0))
                                    {
                                        JObject cell = sheet.ReadCell(r, column.Key, column.Value); cells.Add(cell);
                                        string label = D.Normalize(column.Value), display = D.Field(cell, "text");
                                        if (label == "client") client = display;
                                        if (label == "type de document") type = display;
                                        if (column.Key == h.Motif) motif = display;
                                        if (column.Key == h.State) state = display;
                                    }
                                    string now = D.Now();
                                    result.Rows.Add(D.Obj("id", Guid.NewGuid().ToString(), "schema", "factures-v2", "sourceKey", file + "|FACTURE|" + number,
                                        "sourceFile", Path.GetFileName(file), "sourcePath", Path.GetFullPath(file), "sourceSheet", sheet.Name, "sourceRow", r,
                                        "sourceHeaderRow", h.Row, "sourceValues", cells, "numeroFacture", number, "raisonSociale", client, "siret", "", "typeFacture", type,
                                        "dateLimite", "", "motif", motif, "etatTraitement", state, "agent", "", "statut", "À affecter", "dateImport", now,
                                        "dateAffectation", null, "datePriseEnCharge", null, "dateFin", null, "dmtSecondes", null,
                                        "journal", new JArray(D.Obj("date", now, "auteur", user, "action", "Import facture", "detail", Path.GetFileName(file))), "_hasSourceMotif", h.Motif > 0));
                                }
                            }
                    }
                    catch (Exception ex) { result.Errors.Add(Path.GetFileName(file) + " : " + ex.Message); }
                    finally
                    {
                        try { if (book != null) book.Close(false); }
                        finally { Release((object)sheets); Release((object)book); }
                    }
                }
            return result;
        }
        public ExportResult Export(List<JObject> rows)
        {
            var result = new ExportResult();
            using (var excel = new ExcelSession())
                foreach (var group in rows.GroupBy(r => D.Field(r, "sourcePath"), StringComparer.OrdinalIgnoreCase))
                {
                    string file = group.Key;
                    if (!File.Exists(file)) { result.Errors.Add("Fichier introuvable : " + file); continue; }
                    dynamic book = null, sheets = null;
                    try
                    {
                        book = excel.Open(file, false);
                        if ((bool)book.ReadOnly) throw new IOException("Fichier ouvert en lecture seule. Fermez-le dans Excel avant de reessayer.");
                        sheets = book.Worksheets;
                        var pending = new List<JObject>(); bool backedUp = false;
                        foreach (var sheetGroup in group.GroupBy(r => D.Field(r, "sourceSheet"), StringComparer.OrdinalIgnoreCase))
                        {
                            object native = null;
                            try { native = sheets.Item(sheetGroup.Key); }
                            catch { result.Errors.Add("Feuille introuvable : " + sheetGroup.Key); continue; }
                            using (var sheet = new Sheet(native))
                            {
                                Header h = FindHeader(sheet);
                                if (h == null) { result.Errors.Add("En-tete Numero introuvable : " + sheetGroup.Key); continue; }
                                var targets = new Dictionary<string, List<int>>(StringComparer.OrdinalIgnoreCase);
                                for (int r = h.Row + 1; r <= h.LastRow; r++)
                                {
                                    string num = sheet.Text(r, h.Number); if (num.Length == 0) continue;
                                    if (!targets.ContainsKey(num)) targets[num] = new List<int>(); targets[num].Add(r);
                                }
                                var valid = new List<JObject>();
                                foreach (JObject row in sheetGroup)
                                {
                                    List<int> positions; string number = D.Field(row, "numeroFacture").Trim();
                                    if (!targets.TryGetValue(number, out positions) || positions.Count != 1)
                                    { result.Errors.Add("Facture " + number + " absente ou presente plusieurs fois dans " + sheetGroup.Key + ". Aucun ecrasement."); continue; }
                                    valid.Add(row);
                                }
                                if (valid.Count == 0) continue;
                                if (!backedUp)
                                {
                                    string backups = Path.Combine(Path.GetDirectoryName(file), "Sauvegardes_EPITHETE"); Directory.CreateDirectory(backups);
                                    string backup = Path.Combine(backups, Path.GetFileNameWithoutExtension(file) + "." + DateTime.Now.ToString("yyyyMMdd-HHmmss-fff") + "." + Guid.NewGuid().ToString("N").Substring(0, 8) + Path.GetExtension(file));
                                    File.Copy(file, backup, false); backedUp = true;
                                }
                                if (h.State == 0) { h.State = h.LastCol + 1; sheet.SetText(h.Row, h.State, "Etat du traitement ( noter Traité)"); }
                                foreach (JObject row in valid)
                                { sheet.SetText(targets[D.Field(row, "numeroFacture").Trim()][0], h.State, D.Field(row, "etatTraitement")); pending.Add(row); }
                            }
                        }
                        if (pending.Count > 0) { book.Save(); result.Files++; result.Saved.AddRange(pending); }
                    }
                    catch (Exception ex) { result.Errors.Add("Impossible d'enregistrer " + Path.GetFileName(file) + " : " + ex.Message); }
                    finally
                    {
                        try { if (book != null) book.Close(false); }
                        finally { Release((object)sheets); Release((object)book); }
                    }
                }
            return result;
        }
    }
}

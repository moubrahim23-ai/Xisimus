# Migration ÉPITHÈTE — PowerShell vers C#

| Fonction d'origine | Implémentation livrée |
|---|---|
| Serveurs TCP/HTTP Agent et Manager | Supprimés ; pont WebView2 en mémoire |
| `GET /api/state` | `InvoiceService.State`, sous verrou partagé |
| `POST /api/start`, `finish`, `update` | Contrôles de session et transitions dans `Service.cs` |
| `POST /api/config`, `agents`, `assign` | Opérations Manager dans `Service.cs` |
| Import Excel COM PowerShell | `ExcelFiles.Scan` en C#, puis fusion transactionnelle JSON |
| Export Excel COM PowerShell | `ExcelFiles.Export` en C#, puis validation de `dateExport` |
| `POST /api/shutdown` | Fermeture de la seule fenêtre appelante |
| `fetch` de l'interface | Promesses JavaScript corrélées aux messages natifs |
| Copie navigateur | Presse-papiers Windows, texte et HTML |
| Téléchargement PDF/PPT | Génération locale existante puis dialogue Windows |
| Lanceurs PowerShell de serveurs | Deux EXE et lanceurs CMD sans PowerShell |

Les règles métier, champs JSON, motifs, KPI, filtre des sessions Windows et interfaces du ZIP source sont conservés. Le motif reste en lecture seule : c'est le comportement du code fourni, malgré les indications plus anciennes de son fichier LIRE-MOI.

Les améliorations nécessaires au passage à plusieurs processus natifs sont le verrouillage des lectures, les écritures atomiques, les sauvegardes et le contrôle des changements pendant un export Excel. Aucune base du DP n'est remplacée par la copie jointe.

La génération et les tests du moteur C# sont terminés. La validation de WPF/WebView2, du partage Windows et d'Excel COM sur un poste Windows reste nécessaire ; ces composants ne sont pas disponibles dans l'environnement de préparation.

@echo off
setlocal
if not exist "%~dp0bin\EPITHETE-Manager.exe" (
  echo EXE absent. Utilisez le ZIP complet ou Compiler.ps1.
  pause
  exit /b 1
)
start "EPITHETE Manager" "%~dp0bin\EPITHETE-Manager.exe"
endlocal

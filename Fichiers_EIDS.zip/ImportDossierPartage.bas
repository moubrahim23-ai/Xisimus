Attribute VB_Name = "ImportDossierPartage"
Option Explicit
' ------------------------------------------------------------------
' Import des fichiers de saisie deposes dans le dossier partage.
' Installation : Alt+F11 > Fichier > Importer un fichier... > ce .bas
'                puis enregistrer le classeur en .xlsm.
' Lancement    : Alt+F8 > ImporterDossierPartage
' Auto-lancement a l'ouverture (facultatif), dans ThisWorkbook :
'     Private Sub Workbook_Open(): ImporterDossierPartage: End Sub
' Chaque fichier du dossier peut contenir les feuilles Donnees, Budget,
' Charges (colonnes A:G). Les lignes dont la colonne I commence par
' "EXEMPLE" sont ignorees. La saisie actuelle est REMPLACEE a chaque import.
' ------------------------------------------------------------------
Private Const FEUILLES As String = "Donnees,Budget,Charges"
Private Const DERNIERE_LIGNE As Long = 5000

Public Sub ImporterDossierPartage()
    Dim dossier As String, f As String, wbSrc As Workbook
    Dim nbFichiers As Long, nbLignes As Long
    Dim wsP As Worksheet: Set wsP = ThisWorkbook.Worksheets("Parametres")

    dossier = Trim$(CStr(wsP.Range("B9").Value))
    If dossier = "" Then dossier = ChoisirDossier()
    If dossier = "" Then Exit Sub
    If Right$(dossier, 1) <> Application.PathSeparator Then dossier = dossier & Application.PathSeparator
    If Dir(dossier, vbDirectory) = "" Then
        MsgBox "Dossier introuvable : " & dossier, vbExclamation: Exit Sub
    End If

    On Error GoTo Fin
    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.Calculation = xlCalculationManual
    ViderSaisie

    f = Dir(dossier & "*.xls*")
    Do While f <> ""
        If Left$(f, 2) <> "~$" And StrComp(f, ThisWorkbook.Name, vbTextCompare) <> 0 Then
            Set wbSrc = Workbooks.Open(dossier & f, ReadOnly:=True, UpdateLinks:=0)
            nbLignes = nbLignes + CopierFichier(wbSrc)
            wbSrc.Close SaveChanges:=False
            nbFichiers = nbFichiers + 1
        End If
        f = Dir()
    Loop
    wsP.Range("B9").Value = Left$(dossier, Len(dossier) - 1)
    wsP.Range("B11").Value = Format(Now, "dd/mm/yyyy hh:nn") & " - " & nbFichiers & " fichier(s), " & nbLignes & " ligne(s)"
Fin:
    Dim msg As String: msg = Err.Description
    Application.Calculation = xlCalculationAutomatic
    Application.CalculateFull
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    If msg <> "" Then
        MsgBox "Import interrompu : " & msg, vbCritical
    Else
        MsgBox nbFichiers & " fichier(s) importe(s), " & nbLignes & " ligne(s)." & vbCrLf & _
               "Consultez la feuille Controles.", vbInformation
    End If
End Sub

Private Sub ViderSaisie()
    Dim nom As Variant
    For Each nom In Split(FEUILLES, ",")
        ThisWorkbook.Worksheets(CStr(nom)).Range("A2:G" & DERNIERE_LIGNE).ClearContents
        ThisWorkbook.Worksheets(CStr(nom)).Range("I2:I" & DERNIERE_LIGNE).ClearContents
    Next nom
End Sub

Private Function CopierFichier(wbSrc As Workbook) As Long
    Dim nom As Variant
    For Each nom In Split(FEUILLES, ",")
        CopierFichier = CopierFichier + CopierFeuille(wbSrc, CStr(nom))
    Next nom
End Function

Private Function CopierFeuille(wbSrc As Workbook, nom As String) As Long
    Dim wsS As Worksheet, wsT As Worksheet, v As Variant, sortie() As Variant
    Dim r As Long, c As Long, n As Long, k As Long, derniere As Long, suivante As Long

    On Error Resume Next
    Set wsS = wbSrc.Worksheets(nom)
    On Error GoTo 0
    If wsS Is Nothing Then Exit Function

    derniere = wsS.Cells(wsS.Rows.Count, 1).End(xlUp).Row
    If derniere < 2 Then Exit Function
    v = wsS.Range("A2:I" & derniere).Value
    If Not IsArray(v) Then Exit Function

    For r = 1 To UBound(v, 1)
        If LigneValide(v, r) Then n = n + 1
    Next r
    If n = 0 Then Exit Function

    ReDim sortie(1 To n, 1 To 7)
    For r = 1 To UBound(v, 1)
        If LigneValide(v, r) Then
            k = k + 1
            For c = 1 To 7: sortie(k, c) = v(r, c): Next c
        End If
    Next r

    Set wsT = ThisWorkbook.Worksheets(nom)
    suivante = wsT.Cells(wsT.Rows.Count, 1).End(xlUp).Row + 1
    If suivante < 2 Then suivante = 2
    If suivante + n - 1 > DERNIERE_LIGNE Then
        Err.Raise vbObjectError + 1, , "Plus de " & DERNIERE_LIGNE & " lignes : etendre les formules de la colonne H."
    End If
    wsT.Range(wsT.Cells(suivante, 1), wsT.Cells(suivante + n - 1, 7)).Value = sortie
    CopierFeuille = n
End Function

Private Function LigneValide(v As Variant, r As Long) As Boolean
    LigneValide = Not IsEmpty(v(r, 1)) And Not IsEmpty(v(r, 2)) _
                  And UCase$(Left$(CStr(v(r, 9)), 7)) <> "EXEMPLE"
End Function

Private Function ChoisirDossier() As String
    With Application.FileDialog(msoFileDialogFolderPicker)
        .Title = "Dossier partage contenant les fichiers de saisie"
        If .Show = -1 Then ChoisirDossier = .SelectedItems(1)
    End With
End Function

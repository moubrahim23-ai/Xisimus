Attribute VB_Name = "ImporterCanevas"
Option Explicit
' ------------------------------------------------------------------
' Importe le fichier canevas (4 feuilles) dans les feuilles Src_* du
' tableau de bord, puis tout se recalcule.
' Installation : Alt+F11 > Fichier > Importer un fichier... > ce .bas,
'                puis enregistrer le classeur en .xlsm.
' Lancement    : Alt+F8 > ImporterCanevas
' Source       : Parametres!B7 = dossier OU fichier ; B8 = motif du nom
'                (le fichier le plus recent du dossier est retenu).
' ------------------------------------------------------------------

Public Sub ImporterCanevas()
    Dim wsP As Worksheet, chemin As String, fichier As String
    Dim wbSrc As Workbook, nb As Long, msg As String
    Set wsP = ThisWorkbook.Worksheets("Parametres")

    chemin = Trim$(CStr(wsP.Range("B7").Value))
    fichier = ResoudreFichier(chemin, Trim$(CStr(wsP.Range("B8").Value)))
    If fichier = "" Then Exit Sub

    On Error GoTo Fin
    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.Calculation = xlCalculationManual

    Set wbSrc = Workbooks.Open(fichier, ReadOnly:=True, UpdateLinks:=0)
    Dim annee As Long: annee = CLng(wsP.Range("B4").Value)

    nb = nb + CopierFeuille(TrouverFeuille(wbSrc, "F1", annee), "Src_Feuil1")
    nb = nb + CopierFeuille(TrouverFeuille(wbSrc, "CA", annee), "Src_CA2026")
    nb = nb + CopierFeuille(TrouverFeuille(wbSrc, "CA", annee + 1), "Src_CA2027")
    nb = nb + CopierFeuille(TrouverFeuille(wbSrc, "BILAN", annee), "Src_BILAN")
    wbSrc.Close SaveChanges:=False
    wsP.Range("B9").Value = Format(Now, "dd/mm/yyyy hh:nn") & " - " & Dir(fichier) & " - " & nb & " feuille(s)"
Fin:
    msg = Err.Description
    Application.Calculation = xlCalculationAutomatic
    Application.CalculateFull
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    If msg <> "" Then
        MsgBox "Import interrompu : " & msg, vbCritical
    Else
        MsgBox nb & " feuille(s) importee(s) sur 4." & vbCrLf & "Verifiez la feuille Controles.", vbInformation
    End If
End Sub

Private Function ResoudreFichier(chemin As String, motif As String) As String
    Dim f As String, best As String, bestDate As Date, d As Date
    If motif = "" Then motif = "*.xls*"
    If chemin = "" Then
        With Application.FileDialog(msoFileDialogFilePicker)
            .Title = "Choisir le fichier canevas"
            If .Show = -1 Then ResoudreFichier = .SelectedItems(1)
        End With
        Exit Function
    End If
    If Dir(chemin, vbDirectory) = "" Then
        MsgBox "Chemin introuvable : " & chemin, vbExclamation: Exit Function
    End If
    If (GetAttr(chemin) And vbDirectory) = 0 Then ResoudreFichier = chemin: Exit Function
    If Right$(chemin, 1) <> Application.PathSeparator Then chemin = chemin & Application.PathSeparator
    f = Dir(chemin & motif)
    Do While f <> ""
        If Left$(f, 2) <> "~$" Then
            d = FileDateTime(chemin & f)
            If best = "" Or d > bestDate Then best = f: bestDate = d
        End If
        f = Dir()
    Loop
    If best = "" Then MsgBox "Aucun fichier '" & motif & "' dans " & chemin, vbExclamation: Exit Function
    ResoudreFichier = chemin & best
End Function

Private Function TrouverFeuille(wb As Workbook, genre As String, annee As Long) As Worksheet
    Dim ws As Worksheet, nom As String
    For Each ws In wb.Worksheets
        nom = LCase$(ws.Name)
        Select Case genre
            Case "F1": If UCase$(Trim$(CStr(ws.Cells(1, 1).Value))) = "CLIENT FINAL" Then Set TrouverFeuille = ws
            Case "CA": If nom Like "ca pr?visionnel " & annee Then Set TrouverFeuille = ws
            Case "BILAN": If nom Like "bilan*budget*" Then Set TrouverFeuille = ws
        End Select
        If Not TrouverFeuille Is Nothing Then Exit Function
    Next ws
End Function

Private Function CopierFeuille(wsS As Worksheet, nomDest As String) As Long
    Dim wsD As Worksheet, ur As Range, v As Variant
    If wsS Is Nothing Then Exit Function
    Set wsD = ThisWorkbook.Worksheets(nomDest)
    wsD.Cells.ClearContents
    Set ur = wsS.UsedRange
    v = ur.Value2
    If IsArray(v) Then
        wsD.Cells(ur.Row, ur.Column).Resize(ur.Rows.Count, ur.Columns.Count).Value2 = v
    Else
        wsD.Cells(ur.Row, ur.Column).Value2 = v
    End If
    CopierFeuille = 1
End Function

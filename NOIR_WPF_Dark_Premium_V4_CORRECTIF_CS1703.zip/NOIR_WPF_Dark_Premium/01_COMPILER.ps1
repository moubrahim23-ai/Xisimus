$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$framework = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319'
$compiler = Join-Path $framework 'csc.exe'
if (-not (Test-Path $compiler)) { throw 'Compilateur .NET Framework 4 introuvable.' }
# /noconfig supprime les references ajoutees automatiquement par csc.rsp.
# /nostdlib+ supprime la reference automatique a mscorlib.
# Ainsi chaque assembly est fourni exactement une seule fois.
$names = @('mscorlib','System','System.Core','System.Xml','WindowsBase','PresentationCore','PresentationFramework','System.Xaml','System.Web.Extensions')
$refs = @()
foreach ($name in $names) {
    $local = Join-Path $framework ($name + '.dll')
    if (Test-Path $local) {
        $path = $local
    } else {
        $assembly = [System.Reflection.Assembly]::LoadWithPartialName($name)
        if (-not $assembly -or -not $assembly.Location -or -not (Test-Path $assembly.Location)) {
            throw "Bibliotheque manquante : $name"
        }
        $path = $assembly.Location
    }
    Write-Host "OK $name" -ForegroundColor Green
    $refs += ('/reference:' + $path)
}
$argsCsc = @('/nologo','/noconfig','/nostdlib+','/target:winexe','/platform:anycpu','/out:CalculatricePremium.exe') + $refs + @('Program.cs')
& $compiler @argsCsc
if ($LASTEXITCODE -ne 0) { throw 'Compilation impossible : envoyez les nouvelles erreurs.' }
Write-Host 'SUCCES : CalculatricePremium.exe' -ForegroundColor Green

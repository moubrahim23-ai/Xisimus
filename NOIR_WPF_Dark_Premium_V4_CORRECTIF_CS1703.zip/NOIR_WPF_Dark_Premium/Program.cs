using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Collections.Generic;
using System.Globalization;
using System.Diagnostics;
using System.Web.Script.Serialization;

public class HistoryEntry {
 public string Date {get;set;}
 public string Expression {get;set;}
 public string Result {get;set;}
}
public class Program {
 static Window win;
 static TextBlock display,expression,status;
 static ListBox history;
 static string current="0",operation="",left="";
 static bool fresh=false;
 static List<HistoryEntry> entries=new List<HistoryEntry>();
 static readonly CultureInfo CI=CultureInfo.InvariantCulture;
 static readonly JavaScriptSerializer serializer=new JavaScriptSerializer();
 static readonly string dataPath=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"historique.json");
 [STAThread] public static void Main(){
  try {
   var app=new Application();
   using(var reader=System.Xml.XmlReader.Create(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Interface.xaml")))
    win=(Window)XamlReader.Load(reader);
   display=(TextBlock)win.FindName("Display");expression=(TextBlock)win.FindName("Expression");
   status=(TextBlock)win.FindName("Status");history=(ListBox)win.FindName("History");
   AttachButtons(win);
   ((Button)win.FindName("OpenFolder")).Click+=(s,e)=>Process.Start("explorer.exe",AppDomain.CurrentDomain.BaseDirectory);
   ((Button)win.FindName("ClearHistory")).Click+=(s,e)=>{
    if(MessageBox.Show(win,"Supprimer définitivement tout l'historique ?","Confirmation",MessageBoxButton.YesNo,MessageBoxImage.Question)==MessageBoxResult.Yes){
     var old=new List<HistoryEntry>(entries);entries.Clear();
     if(!Save())entries=old;
     RefreshHistory();
    }
   };
   win.PreviewKeyDown+=(s,e)=>{
    string key=null;
    if(e.Key>=Key.D0&&e.Key<=Key.D9)key=((int)(e.Key-Key.D0)).ToString();
    else if(e.Key>=Key.NumPad0&&e.Key<=Key.NumPad9)key=((int)(e.Key-Key.NumPad0)).ToString();
    else if(e.Key==Key.Add)key="+";
    else if(e.Key==Key.Subtract)key="-";
    else if(e.Key==Key.Multiply)key="*";
    else if(e.Key==Key.Divide)key="/";
    else if(e.Key==Key.Decimal||e.Key==Key.OemComma||e.Key==Key.OemPeriod)key="DECIMAL";
    else if(e.Key==Key.Return||e.Key==Key.Enter)key="=";
    else if(e.Key==Key.Back)key="BACK";
    else if(e.Key==Key.Escape)key="AC";
    if(key!=null){Handle(key);e.Handled=true;}
   };
   Load(); Update();app.Run(win);
  }catch(Exception ex){MessageBox.Show("Démarrage impossible : "+ex.Message);}
 }
 static void AttachButtons(DependencyObject parent){
  foreach(object item in LogicalTreeHelper.GetChildren(parent)){
   var child=item as DependencyObject;
   if(child==null)continue;
   var btn=child as Button;
   if(btn!=null&&btn.Tag!=null){string tag=btn.Tag.ToString();btn.Click+=(s,e)=>Handle(tag);}
   AttachButtons(child);
  }
 }
 static void Load(){
  try{
   if(File.Exists(dataPath)){
    entries=serializer.Deserialize<List<HistoryEntry>>(File.ReadAllText(dataPath,System.Text.Encoding.UTF8))??new List<HistoryEntry>();
   }
   RefreshHistory();
  }catch(Exception ex){status.Text="⚠ JSON illisible : "+ex.Message;status.Foreground=System.Windows.Media.Brushes.Orange;}
 }
 static bool Save(){
  try{
   string tmp=dataPath+".tmp";
   File.WriteAllText(tmp,serializer.Serialize(entries),new System.Text.UTF8Encoding(false));
   if(File.Exists(dataPath))File.Replace(tmp,dataPath,null);
   else File.Move(tmp,dataPath);
   status.Text="● Historique sauvegardé en JSON";
   status.Foreground=System.Windows.Media.Brushes.LightGreen;
   return true;
  }catch(Exception ex){status.Text="⚠ Échec sauvegarde JSON";MessageBox.Show(win,ex.Message,"Sauvegarde",MessageBoxButton.OK,MessageBoxImage.Warning);return false;}
 }
 static void RefreshHistory(){
  history.Items.Clear();
  foreach(var entry in entries.AsEnumerable().Reverse().Take(150))
   history.Items.Add(entry.Date+"  •  "+entry.Expression+" = "+entry.Result);
 }
 static bool Number(out decimal v){return decimal.TryParse(current,NumberStyles.Number,CI,out v);}
 static string Format(decimal d){return d.ToString("0.############################",CI);}
 static void Update(){display.Text=current.Replace('.',',');expression.Text=string.IsNullOrEmpty(operation)?"CALCULATRICE PREMIUM":left.Replace('.',',')+" "+operation.Replace("*","×").Replace("/","÷");}
 static void Handle(string tag){
  try {
   if(tag=="AC"){current="0";left="";operation="";fresh=false;}
   else if(tag=="BACK"){if(fresh){current="0";fresh=false;}else current=current.Length>1?current.Substring(0,current.Length-1):"0";if(current=="-")current="0";}
   else if(tag=="SIGN"){if(current!="0")current=current.StartsWith("-")?current.Substring(1):"-"+current;}
   else if(tag=="DECIMAL"){if(fresh){current="0";fresh=false;}if(!current.Contains("."))current+=".";}
   else if(tag.Length==1&&char.IsDigit(tag[0])){if(fresh||current=="0"){current=tag;fresh=false;}else if(current.Length<24)current+=tag;}
   else if(tag=="%"){decimal v;if(Number(out v)){current=Format(v/100m);fresh=false;}}
   else if(tag=="+"||tag=="-"||tag=="*"||tag=="/"){decimal v;if(Number(out v)){left=current;operation=tag;fresh=true;}}
   else if(tag=="="&&!string.IsNullOrEmpty(operation)){
    decimal a,b;if(!decimal.TryParse(left,NumberStyles.Number,CI,out a)||!Number(out b))return;
    if(operation=="/"&&b==0){MessageBox.Show(win,"Division par zéro impossible.");return;}
    decimal result=operation=="+"?a+b:operation=="-"?a-b:operation=="*"?a*b:a/b;
    string calc=left+" "+operation+" "+current;
    string formatted=Format(result);
    entries.Add(new HistoryEntry{Date=DateTime.Now.ToString("dd/MM/yyyy HH:mm"),Expression=calc.Replace("*","×").Replace("/","÷"),Result=formatted});
    if(!Save())entries.RemoveAt(entries.Count-1);
    RefreshHistory();current=formatted;left="";operation="";fresh=true;
   }
   Update();
  }catch(OverflowException){MessageBox.Show(win,"Nombre trop grand pour le calcul.");}
 }
}
@echo off
cd /d "%~dp0"
if not exist "CalculatricePremium.exe" (echo Compiler d abord avec 01_COMPILER.ps1 & pause & exit /b 1)
start "" "CalculatricePremium.exe"

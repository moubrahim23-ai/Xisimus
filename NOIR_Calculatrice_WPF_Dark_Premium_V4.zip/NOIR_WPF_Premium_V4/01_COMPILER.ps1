$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe'
if (-not (Test-Path $compiler)) { throw 'Compilateur .NET Framework 4 introuvable. Contacter IT.' }
$names = @('mscorlib','System','System.Core','System.Xml','WindowsBase','PresentationCore','PresentationFramework','System.Xaml','System.Web.Extensions')
$references = @()
foreach ($name in $names) {
    $assembly = [System.Reflection.Assembly]::LoadWithPartialName($name)
    if (-not $assembly -or -not $assembly.Location -or -not (Test-Path $assembly.Location)) {
        throw "Bibliotheque introuvable : $name. Verifier la presence de .NET Framework 4.x."
    }
    Write-Host "OK $name" -ForegroundColor Green
    $references += ('/reference:' + $assembly.Location)
}
$argsCsc = @('/nologo','/target:winexe','/platform:anycpu','/out:CalculatricePremium.exe') + $references + @('Program.cs')
& $compiler @argsCsc
if ($LASTEXITCODE -ne 0) { throw 'Compilation impossible. Envoyez la capture des erreurs C#.' }
Write-Host 'SUCCES : CalculatricePremium.exe' -ForegroundColor Green

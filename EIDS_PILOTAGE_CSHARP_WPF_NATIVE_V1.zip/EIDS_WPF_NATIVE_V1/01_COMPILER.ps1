$ErrorActionPreference='Stop'
Set-Location $PSScriptRoot
$csc=Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe'
if (!(Test-Path $csc)) { throw 'Compilateur C# .NET Framework introuvable' }
$names=@('WindowsBase','PresentationCore','PresentationFramework','System.Xaml','System.Web.Extensions','System.Data')
$refs=@()
foreach($name in $names){
 $a=[Reflection.Assembly]::LoadWithPartialName($name)
 if(!$a -or !$a.Location -or !(Test-Path $a.Location)){throw "Bibliothèque introuvable : $name"}
 $refs+=('/reference:"'+$a.Location+'"')
}
# Le compilateur ajoute lui-même mscorlib/System/System.Core : ne pas les référencer en double.
$argsC=@('/nologo','/target:winexe','/out:EIDS_Pilotage.exe')+$refs+@('Program.cs')
& $csc @argsC
if($LASTEXITCODE -ne 0){throw 'Compilation échouée. Consulter les erreurs C# ci-dessus.'}
Write-Host 'EIDS_Pilotage.exe généré.' -ForegroundColor Green

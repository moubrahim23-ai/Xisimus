/* PDF.js analyseur. Aucun téléversement : le PDF est lu localement. */
pdfjsLib.GlobalWorkerOptions.workerSrc='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
const $=id=>document.getElementById(id);
let currentBytes=null;
const bulletChars=['•','●','○','■','▪','◦','‣','⁃','◆','□','∙','●'];
$('file').addEventListener('change',e=>{if(e.target.files[0])loadPDF(e.target.files[0])});
const dz=$('dropzone');
dz.addEventListener('dragover',e=>{e.preventDefault();dz.classList.add('drag')});
dz.addEventListener('dragleave',()=>dz.classList.remove('drag'));
dz.addEventListener('drop',e=>{e.preventDefault();dz.classList.remove('drag');const f=e.dataTransfer.files[0];if(f&&f.type==='application/pdf')loadPDF(f);else alert('Sélectionnez un fichier PDF.')});
$('rescan').onclick=()=>currentBytes&&analyze(currentBytes);
async function loadPDF(file){$('filename').textContent=file.name+' · '+(file.size/1024/1024).toFixed(2)+' Mo';$('workspace').classList.remove('hidden');$('colors').innerHTML='<p class="muted">Analyse en cours…</p>';$('bulletList').innerHTML='';$('pagesPreview').innerHTML='';currentBytes=new Uint8Array(await file.arrayBuffer());await analyze(currentBytes)}
async function analyze(bytes){
 try{
 const doc=await pdfjsLib.getDocument({data:bytes.slice()}).promise;
 $('pagesCount').textContent=doc.numPages;
 const colorCounts=new Map(), bulletCounts=new Map();let pagesWithBullets=0;
 const preview=$('pagesPreview');preview.innerHTML='';
 for(let n=1;n<=doc.numPages;n++){
  const page=await doc.getPage(n), scale=Math.min(1.15,900/page.getViewport({scale:1}).width),vp=page.getViewport({scale});
  const canvas=document.createElement('canvas'),ctx=canvas.getContext('2d',{willReadFrequently:true});canvas.width=Math.floor(vp.width);canvas.height=Math.floor(vp.height);
  await page.render({canvasContext:ctx,viewport:vp}).promise;
  const image=ctx.getImageData(0,0,canvas.width,canvas.height).data;
  // Histogramme des couleurs non blanches échantillonnées, regroupées par pas de 8.
  const local=new Map();
  for(let i=0;i<image.length;i+=4*5){const a=image[i+3];if(a<200)continue;let r=image[i],g=image[i+1],b=image[i+2];if(r>247&&g>247&&b>247)continue;const key=[r,g,b].map(v=>Math.round(v/8)*8).join(',');local.set(key,(local.get(key)||0)+1)}
  for(const [k,v] of local)colorCounts.set(k,(colorCounts.get(k)||0)+v);
  const text=await page.getTextContent();let pageBullets=0;
  for(const item of text.items||[]){if(!item.str)continue;for(const ch of bulletChars){const count=[...item.str].filter(x=>x===ch).length;if(count){bulletCounts.set(ch,(bulletCounts.get(ch)||0)+count);pageBullets+=count}}}
  if(pageBullets)pagesWithBullets++;
  if(n<=8){const card=document.createElement('div');card.className='page-card';card.appendChild(canvas);const lab=document.createElement('small');lab.textContent='Page '+n;card.appendChild(lab);preview.appendChild(card)}
 }
 const top=[...colorCounts.entries()].sort((a,b)=>b[1]-a[1]).slice(0,30);
 $('colorsCount').textContent=top.length;$('bulletsCount').textContent=[...bulletCounts.values()].reduce((a,b)=>a+b,0);
 $('colors').innerHTML='';
 const select=$('oldColor');select.innerHTML='';select.disabled=!top.length;
 top.forEach(([rgb,count],i)=>{const [r,g,b]=rgb.split(',').map(v=>Math.max(0,Math.min(255,v)));const hex='#'+[r,g,b].map(v=>v.toString(16).padStart(2,'0')).join('').toUpperCase();const row=document.createElement('div');row.className='color-row';const sw=document.createElement('span');sw.className='swatch';sw.style.background=hex;const meta=document.createElement('div');meta.className='color-meta';const strong=document.createElement('b');strong.textContent=hex;const small=document.createElement('small');small.textContent=`RGB ${r}, ${g}, ${b} · ${count.toLocaleString('fr-FR')} échantillons`;meta.append(strong,small);const radio=document.createElement('input');radio.type='radio';radio.name='pickColor';radio.value=hex;radio.checked=i===0;radio.onchange=()=>select.value=hex;row.append(sw,meta,radio);$('colors').appendChild(row);const opt=document.createElement('option');opt.value=hex;opt.textContent=hex+' — '+count.toLocaleString('fr-FR');select.appendChild(opt)});
 $('bulletList').innerHTML='';
 if(!bulletCounts.size){$('bulletList').innerHTML='<p class="muted">Aucun caractère de puce courant détecté dans la couche texte.</p>'}
 else [...bulletCounts.entries()].sort((a,b)=>b[1]-a[1]).forEach(([ch,count])=>{const chip=document.createElement('span');chip.className='bullet-chip';const b=document.createElement('b');b.textContent=ch;chip.append(b,document.createTextNode(count+' occurrence(s)'));$('bulletList').appendChild(chip)});
 }catch(err){console.error(err);$('colors').innerHTML='<p class="muted">Impossible de lire ce PDF. Il est peut-être chiffré ou endommagé.</p>'}
}
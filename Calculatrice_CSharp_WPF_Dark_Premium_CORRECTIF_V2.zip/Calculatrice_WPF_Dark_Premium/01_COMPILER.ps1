$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe'
if (-not (Test-Path $compiler)) {
    throw 'Compilateur C# .NET Framework 4 introuvable. Contacter IT.'
}

# Charge les assemblies WPF installees sur Windows pour recuperer leurs vrais chemins.
$names = @('mscorlib','System','System.Core','System.Xml','WindowsBase','PresentationCore','PresentationFramework','System.Xaml','System.Web.Extensions')
$references = @()
foreach ($name in $names) {
    try {
        $assembly = [System.Reflection.Assembly]::Load($name)
        if (-not $assembly -or -not $assembly.Location -or -not (Test-Path $assembly.Location)) {
            throw "Bibliotheque sans chemin local : $name"
        }
        Write-Host ("OK {0} : {1}" -f $name, $assembly.Location)
        $references += '/reference:"' + $assembly.Location + '"'
    } catch {
        throw "Impossible de charger $name. Le composant WPF/.NET peut etre absent ou interdit. Details : $($_.Exception.Message)"
    }
}

$arguments = @('/nologo', '/target:winexe', '/out:CalculatricePremium.exe') + $references + @('Program.cs')
& $compiler @arguments
if ($LASTEXITCODE -ne 0) { throw 'Compilation C# en echec : transmettre les messages ci-dessus.' }
Write-Host 'Compilation reussie : CalculatricePremium.exe' -ForegroundColor Green

using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using Microsoft.Win32;
using System.Web.Script.Serialization;
using D = System.Collections.Generic.Dictionary<string,object>;

public class Program {
 static Window w; static JavaScriptSerializer js=new JavaScriptSerializer(){MaxJsonLength=20000000};
 static D pilot, managers; static DataTable table; static string dataDir=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"data");
 static string pilotFile=Path.Combine(dataDir,"pilotage.json"), managersFile=Path.Combine(dataDir,"collecte_managers.json");
 static ComboBox period,activity,managerActivity; static DataGrid grid,managerGrid; static TextBlock status;
 static string[] fields={"budget","date","days","planned","ca","hours","rate","enc"};
 static string[] headings={"Budget","Situation au","Jours consommés","Jours prévus","CA réalisé","Heures","Coût horaire","Encadrement"};
 static D Obj(object o){return o as D ?? new D();}
 static object Get(D d,string k){object v;return d!=null&&d.TryGetValue(k,out v)?v:null;}
 static string Str(object o){return o==null?"":Convert.ToString(o,CultureInfo.InvariantCulture);}
 static decimal Num(object o){decimal d;return decimal.TryParse(Str(o),NumberStyles.Any,CultureInfo.InvariantCulture,out d)?d:0m;}
 static string Fmt(decimal v){return v.ToString("N2",CultureInfo.GetCultureInfo("fr-FR"));}
 static T Find<T>(string name) where T:FrameworkElement{return (T)w.FindName(name);}
 static D Read(string file){return Obj(js.DeserializeObject(File.ReadAllText(file,Encoding.UTF8)));}
 static bool Write(string file,D obj){try{string tmp=file+".tmp";File.WriteAllText(tmp,js.Serialize(obj),new UTF8Encoding(false));if(File.Exists(file))File.Replace(tmp,file,null);else File.Move(tmp,file);status.Text="● Enregistré : "+DateTime.Now.ToString("HH:mm:ss");return true;}catch(Exception ex){MessageBox.Show(w,ex.Message,"Sauvegarde impossible");return false;}}
 static IEnumerable<D> Projects(){object p=Get(pilot,"projects");return ((object[])p).Select(x=>Obj(x));}
 static string ProjectName(string id){return Str(Get(Projects().FirstOrDefault(p=>Str(Get(p,"id"))==id),"name"));}
 static string SelectedId(ComboBox cb){var item=cb.SelectedItem as ComboBoxItem;return item==null?"":Str(item.Tag);}
 static void FillActivities(ComboBox cb,bool all){cb.Items.Clear();if(all)cb.Items.Add(new ComboBoxItem(){Content="Toutes les activités",Tag="*"});foreach(D p in Projects())cb.Items.Add(new ComboBoxItem(){Content=Str(Get(p,"name")),Tag=Str(Get(p,"id"))});cb.SelectedIndex=0;}
 [STAThread] public static void Main(){try{
  Directory.CreateDirectory(dataDir);
  var app=new Application();using(var reader=System.Xml.XmlReader.Create(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Interface.xaml")))w=(Window)XamlReader.Load(reader);
  status=Find<TextBlock>("Status");period=Find<ComboBox>("Period");activity=Find<ComboBox>("Activity");managerActivity=Find<ComboBox>("ManagerActivity");grid=Find<DataGrid>("PilotGrid");managerGrid=Find<DataGrid>("ManagerGrid");
  pilot=Read(File.Exists(pilotFile)?pilotFile:Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"EXEMPLE_2026_10.json"));
  managers=Read(File.Exists(managersFile)?managersFile:Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"INIT_MANAGERS.json"));
  FillActivities(activity,true);FillActivities(managerActivity,false);Find<DatePicker>("ManagerDate").SelectedDate=DateTime.Today;
  period.SelectionChanged+=(s,e)=>RefreshPilot();activity.SelectionChanged+=(s,e)=>RefreshPilot();
  Find<Button>("Refresh").Click+=(s,e)=>RefreshPilot();Find<Button>("SavePilot").Click+=(s,e)=>SavePilot();
  Find<Button>("SaveManager").Click+=(s,e)=>SaveManager();Find<Button>("LoadManager").Click+=(s,e)=>LoadManager();
  Find<Button>("OpenData").Click+=(s,e)=>Process.Start("explorer.exe",dataDir);
  Find<Button>("ImportPilot").Click+=(s,e)=>Import(true);Find<Button>("ImportManagers").Click+=(s,e)=>Import(false);
  Find<Button>("ExportPilot").Click+=(s,e)=>Export(true);Find<Button>("ExportManagers").Click+=(s,e)=>Export(false);
  managerGrid.SelectionChanged+=(s,e)=>{if(managerGrid.SelectedItem is DataRowView){var r=(DataRowView)managerGrid.SelectedItem;Find<TextBox>("ManagerName").Text=Str(r["Manager"]);SelectActivity(managerActivity,Str(r["Id"]));DateTime dt;if(DateTime.TryParse(Str(r["Date"]),out dt))Find<DatePicker>("ManagerDate").SelectedDate=dt;LoadManager();}};
  PopulatePeriods();RefreshManagers();app.Run(w);
 }catch(Exception ex){MessageBox.Show("Démarrage impossible : "+ex,"EIDS WPF");}}
 static void SelectActivity(ComboBox cb,string id){foreach(ComboBoxItem item in cb.Items)if(Str(item.Tag)==id){cb.SelectedItem=item;return;}}
 static D Records(){return Obj(Get(pilot,"records"));}
 static D Month(string key){D records=Records();object value=Get(records,key);if(value==null){records[key]=new D();value=records[key];}return Obj(value);}
 static void PopulatePeriods(){string selected=Str(period.SelectedItem);period.Items.Clear();var keys=Records().Keys.OrderByDescending(x=>x).ToList();string now=DateTime.Now.ToString("yyyy-MM");if(!keys.Contains(now))keys.Insert(0,now);foreach(string key in keys)period.Items.Add(key);period.SelectedItem=keys.Contains(selected)?selected:keys[0];}
 static string CurrentMonth(){return Str(period.SelectedItem);}
 static void RefreshPilot(){if(period==null||activity==null||period.SelectedItem==null)return;
  table=new DataTable();table.Columns.Add("Id");table.Columns.Add("Activité");foreach(string h in headings)table.Columns.Add(h);
  D month=Month(CurrentMonth());string filter=SelectedId(activity);
  foreach(D p in Projects()){string id=Str(Get(p,"id"));if(filter!="*"&&filter!=id)continue;D r=Obj(Get(month,id));var row=table.NewRow();row["Id"]=id;row["Activité"]=Str(Get(p,"name"));for(int i=0;i<fields.Length;i++)row[headings[i]]=Str(Get(r,fields[i]));table.Rows.Add(row);}
  grid.ItemsSource=table.DefaultView;grid.IsReadOnly=false;decimal ca=0,budget=0,prod=0,forecast=0;
  foreach(D p in Projects()){string id=Str(Get(p,"id"));if(filter!="*"&&filter!=id)continue;D r=Obj(Get(month,id));ca+=Num(Get(r,"ca"));budget+=Num(Get(r,"budget"));prod+=Num(Get(r,"hours"))*Num(Get(r,"rate"));decimal days=Num(Get(r,"days"));if(days>0)forecast+=Num(Get(r,"ca"))/days*Num(Get(r,"planned"));}
  Find<TextBlock>("KpiCa").Text=Fmt(ca)+" €";Find<TextBlock>("KpiBudget").Text=Fmt(budget)+" €";Find<TextBlock>("KpiRatio").Text=ca==0?"—":Fmt(prod/ca*100)+" %";Find<TextBlock>("KpiForecast").Text=Fmt(forecast)+" €";
  RefreshCharts(month,filter,ca,budget);
 }
 static void RefreshCharts(D month,string filter,decimal ca,decimal budget){
  var container=Find<StackPanel>("RevenueChart");container.Children.Clear();
  var values=Projects().Where(p=>filter=="*"||Str(Get(p,"id"))==filter)
   .Select(p=>new {Name=Str(Get(p,"name")),Value=Num(Get(Obj(Get(month,Str(Get(p,"id"))),"ca"))})
   .OrderByDescending(v=>v.Value).Take(9).ToList();
  decimal max=values.Count==0?0:values.Max(v=>v.Value);
  foreach(var item in values){
   var row=new Grid(){Margin=new Thickness(0,3,0,5)};
   row.ColumnDefinitions.Add(new ColumnDefinition(){Width=new GridLength(155)});
   row.ColumnDefinitions.Add(new ColumnDefinition(){Width=new GridLength(1,GridUnitType.Star)});
   row.ColumnDefinitions.Add(new ColumnDefinition(){Width=new GridLength(105)});
   var name=new TextBlock(){Text=item.Name,Foreground=new SolidColorBrush(Color.FromRgb(18,41,71)),FontSize=11,TextTrimming=TextTrimming.CharacterEllipsis,VerticalAlignment=VerticalAlignment.Center,ToolTip=item.Name};
   Grid.SetColumn(name,0);row.Children.Add(name);
   var track=new Border(){Height=12,Background=new SolidColorBrush(Color.FromRgb(231,239,246)),CornerRadius=new CornerRadius(6),HorizontalAlignment=HorizontalAlignment.Stretch,VerticalAlignment=VerticalAlignment.Center};
   var bar=new Border(){Height=12,Background=new SolidColorBrush(Color.FromRgb(32,183,213)),CornerRadius=new CornerRadius(6),HorizontalAlignment=HorizontalAlignment.Left};
   var holder=new Grid(){Margin=new Thickness(6,0,10,0)};holder.Children.Add(track);holder.Children.Add(bar);
   double ratio=max==0?0:(double)(item.Value/max);
   holder.SizeChanged+=(s,e)=>{bar.Width=Math.Max(0,holder.ActualWidth*ratio);};
   Grid.SetColumn(holder,1);row.Children.Add(holder);
   var amount=new TextBlock(){Text=Fmt(item.Value)+" €",Foreground=new SolidColorBrush(Color.FromRgb(18,41,71)),FontWeight=FontWeights.SemiBold,FontSize=11,TextAlignment=TextAlignment.Right,VerticalAlignment=VerticalAlignment.Center};
   Grid.SetColumn(amount,2);row.Children.Add(amount);
   container.Children.Add(row);
  }
  if(values.Count==0)container.Children.Add(new TextBlock(){Text="Aucune donnée disponible",Foreground=Brushes.Gray});
  decimal pct=budget==0?0:ca/budget*100m;
  Find<TextBlock>("BudgetPercent").Text=budget==0?"—":Fmt(pct)+" %";
  Find<ProgressBar>("BudgetProgress").Value=(double)Math.Max(0,Math.Min(100,pct));
  Find<TextBlock>("BudgetDetail").Text="CA : "+Fmt(ca)+" €   •   Budget : "+Fmt(budget)+" €";
 }
 static void SavePilot(){if(table==null)return;grid.CommitEdit(DataGridEditingUnit.Cell,true);grid.CommitEdit(DataGridEditingUnit.Row,true);
  D month=Month(CurrentMonth());try{foreach(DataRow row in table.Rows){string id=Str(row["Id"]);D rec=Obj(Get(month,id));for(int i=0;i<fields.Length;i++){string v=Str(row[headings[i]]).Trim();if(fields[i]=="date")rec[fields[i]]=v;else if(v=="")rec.Remove(fields[i]);else{decimal n;if(!decimal.TryParse(v,NumberStyles.Any,CultureInfo.GetCultureInfo("fr-FR"),out n)&&!decimal.TryParse(v,NumberStyles.Any,CultureInfo.InvariantCulture,out n))throw new Exception("Nombre invalide pour "+id+" : "+headings[i]);if(n<0)throw new Exception("Valeur négative interdite : "+headings[i]);rec[fields[i]]=n;}}month[id]=rec;}if(Write(pilotFile,pilot))RefreshPilot();}catch(Exception ex){MessageBox.Show(w,ex.Message,"Validation");}}
 static DataTable managerTable;
 static void RefreshManagers(){managerTable=new DataTable();foreach(string col in new[]{"Date","Activité","Id","Manager","CA","Heures","Jours","Coût horaire","Encadrement","Commentaire"})managerTable.Columns.Add(col);
  foreach(object o in (object[])Get(managers,"entries")){D e=Obj(o);var row=managerTable.NewRow();string id=Str(Get(e,"projectId"));row["Date"]=Str(Get(e,"date"));row["Id"]=id;row["Activité"]=ProjectName(id);row["Manager"]=Str(Get(e,"manager"));row["CA"]=Str(Get(e,"ca"));row["Heures"]=Str(Get(e,"hours"));row["Jours"]=Str(Get(e,"days"));row["Coût horaire"]=Str(Get(e,"rate"));row["Encadrement"]=Str(Get(e,"enc"));row["Commentaire"]=Str(Get(e,"comment"));managerTable.Rows.Add(row);}managerGrid.ItemsSource=managerTable.DefaultView;}
 static string Val(string name){return Find<TextBox>(name).Text.Trim();}
 static decimal? Optional(string name){string s=Val(name);if(s=="")return null;decimal n;if(!decimal.TryParse(s,NumberStyles.Any,CultureInfo.GetCultureInfo("fr-FR"),out n)&&!decimal.TryParse(s,NumberStyles.Any,CultureInfo.InvariantCulture,out n))throw new Exception("Valeur numérique invalide : "+name);if(n<0)throw new Exception("Valeur négative interdite : "+name);return n;}
 static void Set(D obj,string key,decimal? value){if(value.HasValue)obj[key]=value.Value;else obj.Remove(key);}
 static string Day(){var d=Find<DatePicker>("ManagerDate").SelectedDate;return d.HasValue?d.Value.ToString("yyyy-MM-dd"):"";}
 static void SaveManager(){try{string id=SelectedId(managerActivity),day=Day();if(id==""||day==""||Val("ManagerName")=="")throw new Exception("Manager, activité et date obligatoires.");
  decimal? ca=Optional("DayCa"),hours=Optional("DayHours"),days=Optional("DayConsumed"),rate=Optional("DayRate"),enc=Optional("DayEnc"),budget=Optional("MonthlyBudget"),planned=Optional("MonthlyPlanned");if(days.HasValue&&days.Value!=0&&days.Value!=0.5m&&days.Value!=1)throw new Exception("Journée : 0, 0,5 ou 1.");
  object[] entries=(object[])Get(managers,"entries");D existing=entries.Select(Obj).FirstOrDefault(x=>Str(Get(x,"projectId"))==id&&Str(Get(x,"date"))==day);
  if(existing!=null&&MessageBox.Show(w,"Remplacer la déclaration existante ?","Confirmation",MessageBoxButton.YesNo)!=MessageBoxResult.Yes)return;
  D entry=existing??new D();entry["projectId"]=id;entry["date"]=day;entry["manager"]=Val("ManagerName");entry["comment"]=Val("DayComment");Set(entry,"ca",ca);Set(entry,"hours",hours);Set(entry,"days",days);Set(entry,"rate",rate);Set(entry,"enc",enc);
  if(existing==null)managers["entries"]=entries.Concat(new object[]{entry}).ToArray();
  string month=day.Substring(0,7);object[] budgets=(object[])Get(managers,"budgets");D old=budgets.Select(Obj).FirstOrDefault(x=>Str(Get(x,"projectId"))==id&&Str(Get(x,"month"))==month);if(old==null){old=new D();old["projectId"]=id;old["month"]=month;managers["budgets"]=budgets.Concat(new object[]{old}).ToArray();}Set(old,"budget",budget);Set(old,"planned",planned);
  if(Write(managersFile,managers))RefreshManagers();
 }catch(Exception ex){MessageBox.Show(w,ex.Message,"Validation collecte");}}
 static void LoadManager(){string id=SelectedId(managerActivity),day=Day();if(id==""||day=="")return;D e=((object[])Get(managers,"entries")).Select(Obj).FirstOrDefault(x=>Str(Get(x,"projectId"))==id&&Str(Get(x,"date"))==day);if(e!=null){Find<TextBox>("ManagerName").Text=Str(Get(e,"manager"));Find<TextBox>("DayComment").Text=Str(Get(e,"comment"));}
  string[] inputs={"DayCa","DayHours","DayConsumed","DayRate","DayEnc"},keys={"ca","hours","days","rate","enc"};for(int i=0;i<inputs.Length;i++)Find<TextBox>(inputs[i]).Text=Str(Get(e,keys[i]));
  D b=((object[])Get(managers,"budgets")).Select(Obj).FirstOrDefault(x=>Str(Get(x,"projectId"))==id&&Str(Get(x,"month"))==day.Substring(0,7));Find<TextBox>("MonthlyBudget").Text=Str(Get(b,"budget"));Find<TextBox>("MonthlyPlanned").Text=Str(Get(b,"planned"));}
 static void Import(bool isPilot){var dlg=new OpenFileDialog(){Filter="JSON (*.json)|*.json"};if(dlg.ShowDialog()!=true)return;try{D data=Read(dlg.FileName);if(isPilot){if(!(Get(data,"records") is D)||!(Get(data,"projects") is object[]))throw new Exception("Format pilotage incompatible.");}else{if(Str(Get(data,"kind"))!="eids-manager-collection"||!(Get(data,"entries") is object[]))throw new Exception("Format collecte incompatible.");}if(MessageBox.Show(w,"Importer et remplacer les données locales de cette section ?","Confirmation",MessageBoxButton.YesNo)!=MessageBoxResult.Yes)return;if(isPilot){if(!Write(pilotFile,data))return;pilot=data;FillActivities(activity,true);FillActivities(managerActivity,false);PopulatePeriods();}else{if(!Write(managersFile,data))return;managers=data;RefreshManagers();}}catch(Exception ex){MessageBox.Show(w,ex.Message,"Import impossible");}}
 static void Export(bool isPilot){var dlg=new SaveFileDialog(){Filter="JSON (*.json)|*.json",FileName=(isPilot?"EIDS_pilotage_":"EIDS_collecte_")+DateTime.Now.ToString("yyyyMMdd_HHmm")+".json"};if(dlg.ShowDialog()==true)try{File.WriteAllText(dlg.FileName,js.Serialize(isPilot?pilot:managers),new UTF8Encoding(false));status.Text="● Export JSON créé";}catch(Exception ex){MessageBox.Show(w,ex.Message,"Export impossible");}}
}

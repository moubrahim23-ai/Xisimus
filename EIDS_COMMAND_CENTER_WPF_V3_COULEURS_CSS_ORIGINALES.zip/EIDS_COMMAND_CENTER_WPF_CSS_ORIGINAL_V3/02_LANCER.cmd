@echo off
cd /d "%~dp0"
if not exist EIDS_Pilotage.exe (echo Compiler avec 01_COMPILER.ps1 & pause & exit /b 1)
start "" "EIDS_Pilotage.exe"
